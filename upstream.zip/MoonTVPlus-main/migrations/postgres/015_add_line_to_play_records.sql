-- ============================================
-- 播放记录增加 line 字段（tvbox 这类多线路源记住上次选的线路，续播从该线路进）
-- ============================================

ALTER TABLE play_records ADD COLUMN IF NOT EXISTS line TEXT;
