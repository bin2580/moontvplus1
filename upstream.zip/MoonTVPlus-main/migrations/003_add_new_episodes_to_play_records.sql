-- ============================================
-- 添加 new_episodes 字段到播放记录表
-- 版本: 1.0.1
-- 创建时间: 2026-02-19
-- ============================================

-- 为播放记录表添加 new_episodes 字段（用于显示新增剧集提示）
ALTER TABLE play_records ADD COLUMN new_episodes INTEGER;
