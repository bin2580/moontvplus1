/* eslint-disable @typescript-eslint/ban-ts-comment, @typescript-eslint/no-explicit-any, react-hooks/exhaustive-deps, no-console, @next/next/no-img-element */

'use client';

import {
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Download,
  Gauge,
  GitBranch,
  Heart,
  Loader2,
  Play,
  Radio,
  RefreshCw,
  Tv,
  Wand2,
  X,
} from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useRef, useState } from 'react';

import {
  deleteFavorite,
  generateStorageKey,
  isFavorited as checkIsFavorited,
  isLiveAutoSpeedTestEnabled,
  isLivePlayRecordSavingEnabled,
  saveFavorite,
  savePlayRecord,
  subscribeToDataUpdates,
} from '@/lib/db.client';
import { parseCustomTimeFormat } from '@/lib/time';
import { useLiveSync } from '@/hooks/useLiveSync';

import EpgScrollableRow from '@/components/EpgScrollableRow';
import LoadingStyle, {
  LoadingErrorStyle,
  type LoadingStep,
} from '@/components/LoadingStyle';
import PageLayout from '@/components/PageLayout';

// 扩展 HTMLVideoElement 类型以支持 hls 和 flv 属性
declare global {
  interface HTMLVideoElement {
    hls?: any;
    flv?: any;
  }
}

// 动态导入浏览器专用库
let Artplayer: any = null;
let Hls: any = null;
let flvjs: any = null;

// 直播频道接口
interface LiveChannel {
  id: string;
  tvgId: string;
  name: string;
  logo: string;
  group: string;
  url: string;
}

type MergedChannelItem =
  | {
    type: 'single';
    key: string;
    channel: LiveChannel;
  }
  | {
    type: 'merged';
    key: string;
    name: string;
    group: string;
    logo: string;
    channels: LiveChannel[];
  };

// 直播源接口
interface LiveSource {
  key: string;
  name: string;
  url: string;  // m3u 地址
  ua?: string;
  epg?: string; // 节目单
  from: 'config' | 'custom';
  channelNumber?: number;
  disabled?: boolean;
  proxyMode?: 'full' | 'm3u8-only' | 'direct'; // 代理模式
}

type LiveLineTestResult = {
  status: 'testing' | 'ok' | 'fail';
  type?: 'm3u8' | 'flv' | 'mp4' | 'unknown';
  firstByteMs?: number;
  speedKBps?: number;
  bytesRead?: number;
  testedAt?: number;
  error?: string;
};

/* -----------------------------------------------------------------------------
 * 初始化加载动画（后台「个性化配置 → 初始化加载样式」可切换旧版/方格/魔法阵）
 * 直播是真正的三步线性流程：加载直播源 → 获取直播源 → 就绪。
 * 款式本身见 components/LoadingStyle。
 * -------------------------------------------------------------------------- */
type LiveLoadingStepKey = 'loading' | 'fetching' | 'ready';

const LIVE_LOADING_STEP_META: Record<LiveLoadingStepKey, LoadingStep> = {
  loading: { label: '加载', icon: <Radio /> },
  fetching: { label: '获取', icon: <Download /> },
  ready: { label: '就绪', icon: <Play /> },
};

const LIVE_LOADING_STEPS: LiveLoadingStepKey[] = [
  'loading',
  'fetching',
  'ready',
];

/* 播放器蒙层只有两步：加载，然后播放 */
const LIVE_PLAYER_STEPS: LoadingStep[] = [
  { label: '加载', icon: <Loader2 /> },
  { label: '播放', icon: <Play /> },
];

function LivePageClient() {
  const router = useRouter();
  const searchParams = useSearchParams();

  // 动态加载浏览器专用库
  useEffect(() => {
    if (typeof window !== 'undefined') {
      import('artplayer').then(mod => { Artplayer = mod.default; });
      import('hls.js').then(mod => { Hls = mod.default; });
      import('flv.js').then(mod => { flvjs = mod.default; });

      const runtimeConfig = (window as any).RUNTIME_CONFIG;
      if (runtimeConfig?.LIVE_ENABLED === false) {
        router.replace('/');
      }
    }
  }, [router]);

  // -----------------------------------------------------------------------------
  // 状态变量（State）
  // -----------------------------------------------------------------------------
  const [loading, setLoading] = useState(true);
  const [loadingStage, setLoadingStage] = useState<
    'loading' | 'fetching' | 'ready'
  >('loading');
  const [loadingMessage, setLoadingMessage] = useState('正在加载直播源...');
  const [error, setError] = useState<string | null>(null);

  // 直播源相关
  const [liveSources, setLiveSources] = useState<LiveSource[]>([]);
  const [currentSource, setCurrentSource] = useState<LiveSource | null>(null);
  const currentSourceRef = useRef<LiveSource | null>(null);
  useEffect(() => {
    currentSourceRef.current = currentSource;
  }, [currentSource]);

  // 频道相关
  const [currentChannels, setCurrentChannels] = useState<LiveChannel[]>([]);
  const [currentChannel, setCurrentChannel] = useState<LiveChannel | null>(null);
  useEffect(() => {
    currentChannelRef.current = currentChannel;
  }, [currentChannel]);

  const [needLoadSource] = useState(searchParams.get('source'));
  const [needLoadChannel] = useState(searchParams.get('id'));

  // 播放器相关
  const [videoUrl, setVideoUrl] = useState('');
  const [isVideoLoading, setIsVideoLoading] = useState(false);
  const [unsupportedType, setUnsupportedType] = useState<string | null>(null);

  // 切换直播源状态
  const [isSwitchingSource, setIsSwitchingSource] = useState(false);

  // 分组相关
  const [groupedChannels, setGroupedChannels] = useState<{ [key: string]: LiveChannel[] }>({});
  const [selectedGroup, setSelectedGroup] = useState<string>('');

  // Tab 切换
  const [activeTab, setActiveTab] = useState<'channels' | 'sources'>('channels');

  // 频道列表收起状态
  const [isChannelListCollapsed, setIsChannelListCollapsed] = useState(false);

  // 过滤后的频道列表
  const [filteredChannels, setFilteredChannels] = useState<LiveChannel[]>([]);

  // 搜索关键词
  const [searchKeyword, setSearchKeyword] = useState('');
  const [expandedMergedChannels, setExpandedMergedChannels] = useState<string[]>([]);
  const [lineTestResults, setLineTestResults] = useState<Record<string, LiveLineTestResult>>({});
  const [liveAutoSpeedTest, setLiveAutoSpeedTest] = useState(false);

  // 节目单信息
  const [epgData, setEpgData] = useState<{
    tvgId: string;
    source: string;
    epgUrl: string;
    programs: Array<{
      start: string;
      end: string;
      title: string;
    }>;
  } | null>(null);

  // EPG 数据加载状态
  const [isEpgLoading, setIsEpgLoading] = useState(false);

  // 收藏状态
  const [favorited, setFavorited] = useState(false);
  const favoritedRef = useRef(false);
  const currentChannelRef = useRef<LiveChannel | null>(null);

  // 观影室同步功能
  const liveSync = useLiveSync({
    currentChannelId: currentChannel?.id || '',
    currentChannelName: currentChannel?.name || '',
    currentChannelUrl: currentChannel?.url || '',
    onChannelChange: (channelId, _channelUrl) => {
      // 房员接收到频道切换指令
      if (!currentChannels || !Array.isArray(currentChannels)) return;
      const channel = currentChannels.find(c => c.id === channelId);
      if (channel) {
        handleChannelChange(channel);
      }
    },
  });

  // EPG数据清洗函数 - 去除重叠的节目，保留时间较短的，显示今日节目（18点后包含明天10点前的节目）
  const cleanEpgData = (programs: Array<{ start: string; end: string; title: string }>) => {
    if (!programs || programs.length === 0) return programs;

    // 获取当前时间
    const now = new Date();
    const currentHour = now.getHours();

    // 获取今日日期（只考虑年月日，忽略时间）
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const todayEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);

    // 如果当前时间超过18点，扩展到明天10点
    let endTime = todayEnd;
    if (currentHour >= 18) {
      // 明天10点
      endTime = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 10, 0, 0);
    }

    // 首先过滤出符合时间范围的节目（包括跨天节目）
    const filteredPrograms = programs.filter(program => {
      const programStart = parseCustomTimeFormat(program.start);
      const programEnd = parseCustomTimeFormat(program.end);

      // 使用时间戳进行比较
      const programStartTime = programStart.getTime();
      const programEndTime = programEnd.getTime();
      const todayStartTime = todayStart.getTime();
      const endTimeValue = endTime.getTime();

      // 节目的开始时间在范围内，或者节目在范围内播放（开始时间早于范围开始，但结束时间在范围内）
      return programStartTime < endTimeValue && programEndTime > todayStartTime;
    });

    // 按开始时间排序
    const sortedPrograms = [...filteredPrograms].sort((a, b) => {
      const startA = parseCustomTimeFormat(a.start).getTime();
      const startB = parseCustomTimeFormat(b.start).getTime();
      return startA - startB;
    });

    const cleanedPrograms: Array<{ start: string; end: string; title: string }> = [];

    for (let i = 0; i < sortedPrograms.length; i++) {
      const currentProgram = sortedPrograms[i];
      const currentStart = parseCustomTimeFormat(currentProgram.start);
      const currentEnd = parseCustomTimeFormat(currentProgram.end);

      // 检查是否与已添加的节目重叠
      let hasOverlap = false;

      for (const existingProgram of cleanedPrograms) {
        const existingStart = parseCustomTimeFormat(existingProgram.start);
        const existingEnd = parseCustomTimeFormat(existingProgram.end);

        // 检查时间重叠（考虑完整的日期和时间）
        if (
          (currentStart >= existingStart && currentStart < existingEnd) || // 当前节目开始时间在已存在节目时间段内
          (currentEnd > existingStart && currentEnd <= existingEnd) || // 当前节目结束时间在已存在节目时间段内
          (currentStart <= existingStart && currentEnd >= existingEnd) // 当前节目完全包含已存在节目
        ) {
          hasOverlap = true;
          break;
        }
      }

      // 如果没有重叠，则添加该节目
      if (!hasOverlap) {
        cleanedPrograms.push(currentProgram);
      } else {
        // 如果有重叠，检查是否需要替换已存在的节目
        for (let j = 0; j < cleanedPrograms.length; j++) {
          const existingProgram = cleanedPrograms[j];
          const existingStart = parseCustomTimeFormat(existingProgram.start);
          const existingEnd = parseCustomTimeFormat(existingProgram.end);

          // 检查是否与当前节目重叠（考虑完整的日期和时间）
          if (
            (currentStart >= existingStart && currentStart < existingEnd) ||
            (currentEnd > existingStart && currentEnd <= existingEnd) ||
            (currentStart <= existingStart && currentEnd >= existingEnd)
          ) {
            // 计算节目时长
            const currentDuration = currentEnd.getTime() - currentStart.getTime();
            const existingDuration = existingEnd.getTime() - existingStart.getTime();

            // 如果当前节目时间更短，则替换已存在的节目
            if (currentDuration < existingDuration) {
              cleanedPrograms[j] = currentProgram;
            }
            break;
          }
        }
      }
    }

    return cleanedPrograms;
  };

  // Anime4K超分相关状态
  const [webGPUSupported, setWebGPUSupported] = useState<boolean>(false);
  const [anime4kEnabled, setAnime4kEnabled] = useState<boolean>(false);
  const [anime4kMode, setAnime4kMode] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const v = localStorage.getItem('anime4k_mode');
      if (v !== null) return v;
    }
    return 'ModeA';
  });
  const [anime4kScale, setAnime4kScale] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const v = localStorage.getItem('anime4k_scale');
      if (v !== null) return parseFloat(v);
    }
    return 2.0;
  });
  const anime4kRef = useRef<any>(null);
  const anime4kEnabledRef = useRef(anime4kEnabled);
  const anime4kModeRef = useRef(anime4kMode);
  const anime4kScaleRef = useRef(anime4kScale);
  useEffect(() => {
    anime4kEnabledRef.current = anime4kEnabled;
    anime4kModeRef.current = anime4kMode;
    anime4kScaleRef.current = anime4kScale;
  }, [anime4kEnabled, anime4kMode, anime4kScale]);

  // 播放器引用
  const artPlayerRef = useRef<any>(null);
  const artRef = useRef<HTMLDivElement | null>(null);
  const syncAnime4KCanvasFlip = (flip?: string) => {
    const canvas = anime4kRef.current?.canvas as HTMLCanvasElement | undefined;
    if (!canvas) return;

    const currentFlip = flip || artPlayerRef.current?.flip || 'normal';
    canvas.style.transformOrigin = 'center center';
    canvas.style.transform =
      currentFlip === 'horizontal'
        ? 'scaleX(-1)'
        : currentFlip === 'vertical'
          ? 'scaleY(-1)'
          : 'none';
  };

  // 分组标签滚动相关
  const groupContainerRef = useRef<HTMLDivElement>(null);
  const groupButtonRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const channelListRef = useRef<HTMLDivElement>(null);
  // 记录自动测速已处理过的「直播源:分组」，避免重复测速
  const autoTestedGroupRef = useRef<string>('');
  // 当前测速会话的中断控制器：自动/手动测速共用，切换分组或直播源时统一中断
  const testAbortRef = useRef<AbortController | null>(null);
  // 正在测速的线路 key（同步锁，避免自动/手动在同一帧内重复测同一条线路）
  const inFlightKeysRef = useRef<Set<string>>(new Set());
  // lineTestResults 的同步镜像：handleTestLines 内部逻辑据此判断「已完成/在测」
  const lineTestResultsRef = useRef<Record<string, LiveLineTestResult>>({});

  // -----------------------------------------------------------------------------
  // 工具函数（Utils）
  // -----------------------------------------------------------------------------

  // 获取 logo URL（始终使用代理）
  const getLogoUrl = (logoUrl: string, sourceKey: string) => {
    if (!logoUrl) return '';
    return `/api/proxy/logo?url=${encodeURIComponent(logoUrl)}&source=${sourceKey}`;
  };

  // 获取直播源列表
  const fetchLiveSources = async () => {
    try {
      setLoadingStage('fetching');
      setLoadingMessage('正在获取直播源...');

      // 获取 AdminConfig 中的直播源信息
      const response = await fetch('/api/live/sources');
      if (!response.ok) {
        throw new Error('获取直播源失败');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || '获取直播源失败');
      }

      const sources = result.data;
      setLiveSources(sources);

      if (sources.length > 0) {
        // 默认选中第一个源
        const firstSource = sources[0];
        if (needLoadSource) {
          const foundSource = sources.find((s: LiveSource) => s.key === needLoadSource);
          if (foundSource) {
            setCurrentSource(foundSource);
            await fetchChannels(foundSource);
          } else {
            setCurrentSource(firstSource);
            await fetchChannels(firstSource);
          }
        } else {
          setCurrentSource(firstSource);
          await fetchChannels(firstSource);
        }
      }

      setLoadingStage('ready');
      setLoadingMessage('✨ 准备就绪...');

      setTimeout(() => {
        setLoading(false);
      }, 1000);
    } catch (err) {
      console.error('获取直播源失败:', err);
      // 不设置错误，而是显示空状态
      setLiveSources([]);
      setLoading(false);
    }
  };

  // 获取频道列表
  const fetchChannels = async (source: LiveSource) => {
    try {
      setIsVideoLoading(true);

      // 从 cachedLiveChannels 获取频道信息
      const response = await fetch(`/api/live/channels?source=${source.key}`);
      if (!response.ok) {
        throw new Error('获取频道列表失败');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || '获取频道列表失败');
      }

      const channelsData = result.data;
      if (!channelsData || channelsData.length === 0) {
        // 不抛出错误，而是设置空频道列表
        setCurrentChannels([]);
        setGroupedChannels({});
        setFilteredChannels([]);

        // 更新直播源的频道数为 0
        setLiveSources(prevSources =>
          prevSources.map(s =>
            s.key === source.key ? { ...s, channelNumber: 0 } : s
          )
        );

        setIsVideoLoading(false);
        return;
      }

      // 转换频道数据格式
      const channels: LiveChannel[] = channelsData.map((channel: any) => ({
        id: channel.id,
        tvgId: channel.tvgId || channel.name,
        name: channel.name,
        logo: channel.logo,
        group: channel.group || '其他',
        url: channel.url
      }));

      setCurrentChannels(channels);

      // 更新直播源的频道数
      setLiveSources(prevSources =>
        prevSources.map(s =>
          s.key === source.key ? { ...s, channelNumber: channels.length } : s
        )
      );

      // 默认选中第一个频道
      if (channels.length > 0) {
        let selectedChannel: LiveChannel | null = null;

        if (needLoadChannel) {
          const foundChannel = channels.find((c: LiveChannel) => c.id === needLoadChannel);
          if (foundChannel) {
            selectedChannel = foundChannel;
            setCurrentChannel(foundChannel);
            setVideoUrl(foundChannel.url);
            // 延迟滚动到选中的频道
            setTimeout(() => {
              scrollToChannel(foundChannel);
            }, 200);
          } else {
            selectedChannel = channels[0];
            setCurrentChannel(channels[0]);
            setVideoUrl(channels[0].url);
          }
        } else {
          selectedChannel = channels[0];
          setCurrentChannel(channels[0]);
          setVideoUrl(channels[0].url);
        }

        // 异步获取初始频道的节目单（不阻塞页面加载）
        if (selectedChannel) {
          fetchEpgData(selectedChannel, source);

          // 保存播放记录（由本地设置控制，默认关闭）
          if (isLivePlayRecordSavingEnabled()) {
            try {
              await savePlayRecord(`live_${source.key}`, `live_${selectedChannel.id}`, {
                title: selectedChannel.name,
                source_name: source.name,
                year: '',
                cover: getLogoUrl(selectedChannel.logo, source.key),
                index: 1,
                total_episodes: 1,
                play_time: 0,
                total_time: 0,
                save_time: Date.now(),
                search_title: '',
                origin: 'live',
              });
            } catch (err) {
              console.error('保存播放记录失败:', err);
            }
          }

          // 更新URL参数
          const newSearchParams = new URLSearchParams(searchParams.toString());
          newSearchParams.set('source', source.key);
          newSearchParams.set('id', selectedChannel.id);

          const newUrl = `?${newSearchParams.toString()}`;
          router.replace(newUrl);
        }
      }

      // 按分组组织频道
      const grouped = channels.reduce((acc, channel) => {
        const group = channel.group || '其他';
        if (!acc[group]) {
          acc[group] = [];
        }
        acc[group].push(channel);
        return acc;
      }, {} as { [key: string]: LiveChannel[] });

      setGroupedChannels(grouped);

      // 默认选中当前加载的channel所在的分组，如果没有则选中第一个分组
      let targetGroup = '';
      if (needLoadChannel) {
        const foundChannel = channels.find((c: LiveChannel) => c.id === needLoadChannel);
        if (foundChannel) {
          targetGroup = foundChannel.group || '其他';
        }
      }

      // 如果目标分组不存在，则使用第一个分组
      if (!targetGroup || !grouped[targetGroup]) {
        targetGroup = Object.keys(grouped)[0] || '';
      }

      // 先设置过滤后的频道列表，但不设置选中的分组
      setFilteredChannels(targetGroup ? grouped[targetGroup] : channels);

      // 触发模拟点击分组，让模拟点击来设置分组状态和触发滚动
      if (targetGroup) {
        // 确保切换到频道tab
        setActiveTab('channels');

        // 使用更长的延迟，确保状态更新和DOM渲染完成
        setTimeout(() => {
          simulateGroupClick(targetGroup);
        }, 500); // 增加延迟时间，确保状态更新和DOM渲染完成
      }

      setIsVideoLoading(false);
    } catch (err) {
      console.error('获取频道列表失败:', err);
      // 不设置错误，而是设置空频道列表
      setCurrentChannels([]);
      setGroupedChannels({});
      setFilteredChannels([]);

      // 更新直播源的频道数为 0
      setLiveSources(prevSources =>
        prevSources.map(s =>
          s.key === source.key ? { ...s, channelNumber: 0 } : s
        )
      );

      setIsVideoLoading(false);
    }
  };

  // 切换直播源
  const handleSourceChange = async (source: LiveSource) => {
    try {
      // 设置切换状态，锁住频道切换器
      setIsSwitchingSource(true);

      // 首先销毁当前播放器
      cleanupPlayer();

      // 重置不支持的类型状态
      setUnsupportedType(null);

      // 清空节目单信息
      setEpgData(null);

      // 清空搜索关键词
      setSearchKeyword('');

      setCurrentSource(source);
      await fetchChannels(source);

      // 更新URL参数 - 切换直播源时清除频道id，因为新的直播源会有不同的频道列表
      const newSearchParams = new URLSearchParams(searchParams.toString());
      newSearchParams.set('source', source.key);
      newSearchParams.delete('id'); // 清除频道id

      const newUrl = `?${newSearchParams.toString()}`;
      router.replace(newUrl);
    } catch (err) {
      console.error('切换直播源失败:', err);
      // 不设置错误，保持当前状态
    } finally {
      // 切换完成，解锁频道切换器
      setIsSwitchingSource(false);
      // 自动切换到频道 tab
      setActiveTab('channels');
    }
  };

  // 获取节目单信息的辅助函数
  const fetchEpgData = async (channel: LiveChannel, source: LiveSource) => {
    if (channel.tvgId && source) {
      try {
        setIsEpgLoading(true); // 开始加载 EPG 数据
        const response = await fetch(`/api/live/epg?source=${source.key}&tvgId=${channel.tvgId}`);
        if (response.ok) {
          const result = await response.json();
          if (result.success) {
            // 清洗EPG数据，去除重叠的节目
            const cleanedData = {
              ...result.data,
              programs: cleanEpgData(result.data.programs)
            };
            setEpgData(cleanedData);
          }
        }
      } catch (error) {
        console.error('获取节目单信息失败:', error);
      } finally {
        setIsEpgLoading(false); // 无论成功失败都结束加载状态
      }
    } else {
      // 如果没有 tvgId 或 source，清空 EPG 数据
      setEpgData(null);
      setIsEpgLoading(false);
    }
  };

  // 切换频道
  const handleChannelChange = async (channel: LiveChannel) => {
    // 如果正在切换直播源，则禁用频道切换
    if (isSwitchingSource) return;

    // 首先销毁当前播放器
    cleanupPlayer();

    // 重置不支持的类型状态
    setUnsupportedType(null);

    setCurrentChannel(channel);
    setVideoUrl(channel.url);

    // 更新URL参数
    if (currentSource) {
      const newSearchParams = new URLSearchParams(searchParams.toString());
      newSearchParams.set('source', currentSource.key);
      newSearchParams.set('id', channel.id);

      const newUrl = `?${newSearchParams.toString()}`;
      router.replace(newUrl);
    }

    // 自动滚动到选中的频道位置
    setTimeout(() => {
      scrollToChannel(channel);
    }, 100);

    // 获取节目单信息
    if (currentSource) {
      await fetchEpgData(channel, currentSource);
    }

    // 保存播放记录（由本地设置控制，默认关闭）
    if (currentSource && isLivePlayRecordSavingEnabled()) {
      try {
        await savePlayRecord(`live_${currentSource.key}`, `live_${channel.id}`, {
          title: channel.name,
          source_name: currentSource.name,
          year: '',
          cover: getLogoUrl(channel.logo, currentSource.key),
          index: 1,
          total_episodes: 1,
          play_time: 0,
          total_time: 0,
          save_time: Date.now(),
          search_title: '',
          origin: 'live',
        });
      } catch (err) {
        console.error('保存播放记录失败:', err);
      }
    }
  };

  // 滚动到指定频道位置的函数
  const scrollToChannel = (channel: LiveChannel) => {
    if (!channelListRef.current) return;

    // 使用 data 属性来查找频道元素
    const targetElement = channelListRef.current.querySelector(`[data-channel-id="${channel.id}"]`) as HTMLButtonElement;

    if (targetElement) {
      // 计算滚动位置，使频道居中显示
      const container = channelListRef.current;
      const containerRect = container.getBoundingClientRect();
      const elementRect = targetElement.getBoundingClientRect();

      // 计算目标滚动位置
      const scrollTop = container.scrollTop + (elementRect.top - containerRect.top) - (containerRect.height / 2) + (elementRect.height / 2);

      // 平滑滚动到目标位置
      container.scrollTo({
        top: Math.max(0, scrollTop),
        behavior: 'smooth'
      });
    }
  };

  // 模拟点击分组的函数
  const simulateGroupClick = (group: string, retryCount = 0) => {
    if (!groupContainerRef.current) {
      if (retryCount < 10) {
        setTimeout(() => {
          simulateGroupClick(group, retryCount + 1);
        }, 200);
        return;
      } else {
        return;
      }
    }

    // 直接通过 data-group 属性查找目标按钮
    const targetButton = groupContainerRef.current.querySelector(`[data-group="${group}"]`) as HTMLButtonElement;

    if (targetButton) {
      // 手动设置分组状态，确保状态一致性
      setSelectedGroup(group);

      // 触发点击事件
      (targetButton as HTMLButtonElement).click();
    }
  };

  // 初始化Anime4K超分
  const initAnime4K = async () => {
    if (!artPlayerRef.current?.video) return;

    let frameRequestId: number | null = null;
    let outputCanvas: HTMLCanvasElement | null = null;

    try {
      if (anime4kRef.current) {
        anime4kRef.current.stop?.();
        anime4kRef.current = null;
      }

      const video = artPlayerRef.current.video as HTMLVideoElement;

      // 等待视频元数据加载完成
      if (!video.videoWidth || !video.videoHeight) {
        console.warn('视频尺寸未就绪，等待loadedmetadata事件');
        await new Promise<void>((resolve) => {
          const handler = () => {
            video.removeEventListener('loadedmetadata', handler);
            resolve();
          };
          video.addEventListener('loadedmetadata', handler);
          if (video.videoWidth && video.videoHeight) {
            video.removeEventListener('loadedmetadata', handler);
            resolve();
          }
        });
      }

      if (!video.videoWidth || !video.videoHeight) {
        throw new Error('无法获取视频尺寸');
      }

      // 检测是否为Firefox
      const isFirefox = navigator.userAgent.toLowerCase().includes('firefox');

      // 创建输出canvas
      outputCanvas = document.createElement('canvas');
      const container = artPlayerRef.current.template.$video.parentElement;

      const scale = anime4kScaleRef.current;
      outputCanvas.width = Math.floor(video.videoWidth * scale);
      outputCanvas.height = Math.floor(video.videoHeight * scale);

      if (!outputCanvas.width || !outputCanvas.height ||
          !isFinite(outputCanvas.width) || !isFinite(outputCanvas.height)) {
        throw new Error(`outputCanvas尺寸无效: ${outputCanvas.width}x${outputCanvas.height}`);
      }

      outputCanvas.style.position = 'absolute';
      outputCanvas.style.top = '0';
      outputCanvas.style.left = '0';
      outputCanvas.style.width = '100%';
      outputCanvas.style.height = '100%';
      outputCanvas.style.objectFit = 'contain';
      outputCanvas.style.cursor = 'pointer';
      outputCanvas.style.zIndex = '1';
      outputCanvas.style.backgroundColor = 'transparent';

      // Firefox兼容性处理
      let sourceCanvas: HTMLCanvasElement | null = null;
      let sourceCtx: CanvasRenderingContext2D | null = null;

      if (isFirefox) {
        sourceCanvas = document.createElement('canvas');
        const canvasW = Math.floor(video.videoWidth);
        const canvasH = Math.floor(video.videoHeight);
        sourceCanvas.width = canvasW;
        sourceCanvas.height = canvasH;

        if (!sourceCanvas.width || !sourceCanvas.height) {
          throw new Error(`sourceCanvas尺寸无效: ${sourceCanvas.width}x${sourceCanvas.height}`);
        }

        sourceCtx = sourceCanvas.getContext('2d', {
          willReadFrequently: true,
          alpha: false
        });

        if (!sourceCtx) {
          throw new Error('无法创建2D上下文');
        }

        if (video.readyState >= video.HAVE_CURRENT_DATA) {
          sourceCtx.drawImage(video, 0, 0, sourceCanvas.width, sourceCanvas.height);
        }
      }

      // 监听点击和双击事件
      const handleCanvasClick = () => {
        if (artPlayerRef.current) {
          artPlayerRef.current.toggle();
        }
      };
      const handleCanvasDblClick = () => {
        if (artPlayerRef.current) {
          artPlayerRef.current.fullscreen = !artPlayerRef.current.fullscreen;
        }
      };
      outputCanvas.addEventListener('click', handleCanvasClick);
      outputCanvas.addEventListener('dblclick', handleCanvasDblClick);

      // 隐藏原始video
      video.style.opacity = '0';
      video.style.pointerEvents = 'none';
      video.style.position = 'absolute';
      video.style.zIndex = '-1';

      container.insertBefore(outputCanvas, video);

      // Firefox视频帧捕获
      if (isFirefox && sourceCtx && sourceCanvas) {
        const captureVideoFrame = () => {
          if (sourceCtx && sourceCanvas && video.readyState >= video.HAVE_CURRENT_DATA) {
            sourceCtx.drawImage(video, 0, 0, sourceCanvas.width, sourceCanvas.height);
          }
          frameRequestId = requestAnimationFrame(captureVideoFrame);
        };
        captureVideoFrame();
      }

      // 动态导入anime4k-webgpu
      const { render: anime4kRender, ModeA, ModeB, ModeC, ModeAA, ModeBB, ModeCA } = await import(
        /* webpackChunkName: "anime4k-webgpu" */
        /* webpackMode: "lazy" */
        'anime4k-webgpu'
      );

      let ModeClass: any;
      const modeName = anime4kModeRef.current;

      switch (modeName) {
        case 'ModeA': ModeClass = ModeA; break;
        case 'ModeB': ModeClass = ModeB; break;
        case 'ModeC': ModeClass = ModeC; break;
        case 'ModeAA': ModeClass = ModeAA; break;
        case 'ModeBB': ModeClass = ModeBB; break;
        case 'ModeCA': ModeClass = ModeCA; break;
        default: ModeClass = ModeA;
      }

      const renderConfig: any = {
        video: isFirefox ? sourceCanvas : video,
        canvas: outputCanvas,
        pipelineBuilder: (device: GPUDevice, inputTexture: GPUTexture) => {
          if (!outputCanvas) {
            throw new Error('outputCanvas is null in pipelineBuilder');
          }
          const mode = new ModeClass({
            device,
            inputTexture,
            nativeDimensions: {
              width: Math.floor(video.videoWidth),
              height: Math.floor(video.videoHeight),
            },
            targetDimensions: {
              width: Math.floor(outputCanvas.width),
              height: Math.floor(outputCanvas.height),
            },
          });
          return [mode];
        },
      };

      const controller = await anime4kRender(renderConfig);

      anime4kRef.current = {
        controller,
        canvas: outputCanvas,
        sourceCanvas: isFirefox ? sourceCanvas : null,
        frameRequestId: isFirefox ? frameRequestId : null,
        handleCanvasClick,
        handleCanvasDblClick,
      };
      syncAnime4KCanvasFlip();

      console.log('Anime4K超分已启用，模式:', anime4kModeRef.current, '倍数:', scale);
      if (artPlayerRef.current) {
        artPlayerRef.current.notice.show = `超分已启用 (${anime4kModeRef.current}, ${scale}x)`;
      }
    } catch (err) {
      console.error('初始化Anime4K失败:', err);

      // 清理已创建的资源
      if (frameRequestId) {
        cancelAnimationFrame(frameRequestId);
      }

      if (outputCanvas && outputCanvas.parentNode) {
        outputCanvas.parentNode.removeChild(outputCanvas);
      }

      if (artPlayerRef.current?.video) {
        artPlayerRef.current.video.style.opacity = '1';
        artPlayerRef.current.video.style.pointerEvents = 'auto';
        artPlayerRef.current.video.style.position = '';
        artPlayerRef.current.video.style.zIndex = '';
      }

      // 显示错误信息
      if (artPlayerRef.current) {
        const errorMsg = err instanceof Error ? err.message : '未知错误';
        artPlayerRef.current.notice.show = '超分启用失败：' + errorMsg;
      }

      // 重新抛出错误，让调用者知道失败了
      throw err;
    }
  };

  // 清理Anime4K
  const cleanupAnime4K = async () => {
    if (anime4kRef.current) {
      try {
        if (anime4kRef.current.frameRequestId) {
          cancelAnimationFrame(anime4kRef.current.frameRequestId);
        }

        anime4kRef.current.controller?.stop?.();

        if (anime4kRef.current.canvas) {
          if (anime4kRef.current.handleCanvasClick) {
            anime4kRef.current.canvas.removeEventListener('click', anime4kRef.current.handleCanvasClick);
          }
          if (anime4kRef.current.handleCanvasDblClick) {
            anime4kRef.current.canvas.removeEventListener('dblclick', anime4kRef.current.handleCanvasDblClick);
          }
        }

        if (anime4kRef.current.canvas && anime4kRef.current.canvas.parentNode) {
          anime4kRef.current.canvas.parentNode.removeChild(anime4kRef.current.canvas);
        }

        if (anime4kRef.current.sourceCanvas) {
          const ctx = anime4kRef.current.sourceCanvas.getContext('2d');
          if (ctx) {
            ctx.clearRect(0, 0, anime4kRef.current.sourceCanvas.width, anime4kRef.current.sourceCanvas.height);
          }
        }

        anime4kRef.current = null;

        if (artPlayerRef.current?.video) {
          artPlayerRef.current.video.style.opacity = '1';
          artPlayerRef.current.video.style.pointerEvents = 'auto';
          artPlayerRef.current.video.style.position = '';
          artPlayerRef.current.video.style.zIndex = '';
        }

        console.log('Anime4K已清理');
      } catch (err) {
        console.warn('清理Anime4K时出错:', err);
      }
    }
  };

  // 切换Anime4K状态
  const toggleAnime4K = async (enabled: boolean) => {
    try {
      if (enabled) {
        // 检查视频是否准备好
        if (!artPlayerRef.current?.video) {
          if (artPlayerRef.current) {
            artPlayerRef.current.notice.show = '视频未准备好，请稍后再试';
          }
          return false;
        }
        await initAnime4K();
      } else {
        await cleanupAnime4K();
      }
      setAnime4kEnabled(enabled);
      localStorage.setItem('enable_anime4k', String(enabled));
      return enabled;
    } catch (err) {
      console.error('切换超分状态失败:', err);
      if (artPlayerRef.current) {
        artPlayerRef.current.notice.show = '切换超分状态失败';
      }
      return !enabled; // 返回原来的状态
    }
  };

  // 更改Anime4K模式
  const changeAnime4KMode = async (mode: string) => {
    try {
      setAnime4kMode(mode);
      localStorage.setItem('anime4k_mode', mode);

      if (anime4kEnabledRef.current) {
        // 检查视频是否准备好
        if (!artPlayerRef.current?.video) {
          if (artPlayerRef.current) {
            artPlayerRef.current.notice.show = '视频未准备好，请稍后再试';
          }
          return;
        }
        await cleanupAnime4K();
        await initAnime4K();
      }
    } catch (err) {
      console.error('更改超分模式失败:', err);
      if (artPlayerRef.current) {
        artPlayerRef.current.notice.show = '更改超分模式失败';
      }
    }
  };

  // 更改Anime4K分辨率倍数
  const changeAnime4KScale = async (scale: number) => {
    try {
      setAnime4kScale(scale);
      localStorage.setItem('anime4k_scale', scale.toString());

      if (anime4kEnabledRef.current) {
        // 检查视频是否准备好
        if (!artPlayerRef.current?.video) {
          if (artPlayerRef.current) {
            artPlayerRef.current.notice.show = '视频未准备好，请稍后再试';
          }
          return;
        }
        await cleanupAnime4K();
        await initAnime4K();
      }
    } catch (err) {
      console.error('更改超分倍数失败:', err);
      if (artPlayerRef.current) {
        artPlayerRef.current.notice.show = '更改超分倍数失败';
      }
    }
  };

  // 清理播放器资源的统一函数
  const cleanupPlayer = () => {
    // 重置不支持的类型状态
    setUnsupportedType(null);

    // 清理Anime4K
    cleanupAnime4K();

    if (artPlayerRef.current) {
      try {
        // 先暂停播放
        if (artPlayerRef.current.video) {
          artPlayerRef.current.video.pause();
          artPlayerRef.current.video.src = '';
          artPlayerRef.current.video.load();
        }

        // 销毁 HLS 实例
        if (artPlayerRef.current.video && artPlayerRef.current.video.hls) {
          artPlayerRef.current.video.hls.destroy();
          artPlayerRef.current.video.hls = null;
        }

        // 销毁 FLV 实例 - 增强清理逻辑
        if (artPlayerRef.current.video && artPlayerRef.current.video.flv) {
          try {
            // 先停止加载
            if (artPlayerRef.current.video.flv.unload) {
              artPlayerRef.current.video.flv.unload();
            }
            // 销毁播放器
            artPlayerRef.current.video.flv.destroy();
            // 确保引用被清空
            artPlayerRef.current.video.flv = null;
          } catch (flvError) {
            console.warn('FLV实例销毁时出错:', flvError);
            // 强制清空引用
            artPlayerRef.current.video.flv = null;
          }
        }

        // 移除所有事件监听器
        artPlayerRef.current.off('ready');
        artPlayerRef.current.off('loadstart');
        artPlayerRef.current.off('loadeddata');
        artPlayerRef.current.off('canplay');
        artPlayerRef.current.off('waiting');
        artPlayerRef.current.off('error');

        // 销毁 ArtPlayer 实例
        artPlayerRef.current.destroy();
        artPlayerRef.current = null;
      } catch (err) {
        console.warn('清理播放器资源时出错:', err);
        artPlayerRef.current = null;
      }
    }
  };

  // 确保视频源正确设置
  const ensureVideoSource = (video: HTMLVideoElement | null, url: string) => {
    if (!video || !url) return;
    const sources = Array.from(video.getElementsByTagName('source'));
    const existed = sources.some((s) => s.src === url);
    if (!existed) {
      // 移除旧的 source，保持唯一
      sources.forEach((s) => s.remove());
      const sourceEl = document.createElement('source');
      sourceEl.src = url;
      video.appendChild(sourceEl);
    }

    // 始终允许远程播放（AirPlay / Cast）
    video.disableRemotePlayback = false;
    // 如果曾经有禁用属性，移除之
    if (video.hasAttribute('disableRemotePlayback')) {
      video.removeAttribute('disableRemotePlayback');
    }
  };

  // 过滤频道（根据分组和搜索关键词）
  const filterChannels = (group: string, keyword: string) => {
    if (!currentChannels || !Array.isArray(currentChannels)) return [];

    let filtered = currentChannels.filter(channel => channel.group === group);

    // 如果有搜索关键词，进一步过滤
    if (keyword.trim()) {
      filtered = filtered.filter(channel =>
        channel.name.toLowerCase().includes(keyword.toLowerCase())
      );
    }

    return filtered;
  };

  const mergedChannelItems = useMemo<MergedChannelItem[]>(() => {
    if (!filteredChannels || filteredChannels.length === 0) return [];

    const mergedMap = new Map<string, {
      key: string;
      name: string;
      group: string;
      logo: string;
      channels: LiveChannel[];
    }>();
    const order: string[] = [];

    filteredChannels.forEach((channel) => {
      const mergedKey = `${channel.group}::${channel.name.trim().toLowerCase()}`;
      const existing = mergedMap.get(mergedKey);

      if (existing) {
        existing.channels.push(channel);
        if (!existing.logo && channel.logo) {
          existing.logo = channel.logo;
        }
        return;
      }

      mergedMap.set(mergedKey, {
        key: mergedKey,
        name: channel.name,
        group: channel.group,
        logo: channel.logo,
        channels: [channel],
      });
      order.push(mergedKey);
    });

    return order.map((key) => {
      const item = mergedMap.get(key);
      if (!item) {
        return null;
      }
      if (item.channels.length === 1) {
        return {
          type: 'single',
          key,
          channel: item.channels[0],
        };
      }

      return {
        type: 'merged',
        key,
        name: item.name,
        group: item.group,
        logo: item.logo,
        channels: item.channels,
      };
    }).filter((item): item is MergedChannelItem => item !== null);
  }, [filteredChannels]);

  const toggleMergedChannel = (key: string) => {
    setExpandedMergedChannels((prev) => (
      prev.includes(key)
        ? prev.filter(item => item !== key)
        : [...prev, key]
    ));
  };

  const getLineTestKey = (channel: LiveChannel) => {
    return `${currentSourceRef.current?.key || currentSource?.key || ''}:${channel.id}:${channel.url}`;
  };

  const formatLineSpeed = (speedKBps?: number) => {
    if (!speedKBps || speedKBps <= 0) return '';
    if (speedKBps >= 1024) return `${(speedKBps / 1024).toFixed(1)} MB/s`;
    return `${speedKBps.toFixed(0)} KB/s`;
  };

  // 卡片上的紧凑速度，避免占满一行
  const formatLineSpeedCompact = (speedKBps?: number) => {
    if (!speedKBps || speedKBps <= 0) return '';
    if (speedKBps >= 1024) return `${(speedKBps / 1024).toFixed(1)}M/s`;
    return `${speedKBps.toFixed(0)}K/s`;
  };

  const formatLineLatency = (firstByteMs?: number) => {
    if (!firstByteMs || firstByteMs <= 0) return '';
    return `${Math.round(firstByteMs)}ms`;
  };

  const getLineTestLabel = (channel: LiveChannel) => {
    const result = lineTestResults[getLineTestKey(channel)];
    if (!result) return '';
    if (result.status === 'testing') return '测量中...';
    if (result.status === 'fail') return '不可用';

    const speed = formatLineSpeed(result.speedKBps);
    const latency = formatLineLatency(result.firstByteMs);
    if (speed && latency) return `${speed} · ${latency}`;
    return speed || latency || '可用';
  };

  // 卡片上展示的徽标文字：短、不会换行
  const getLineTestBadge = (channel: LiveChannel) => {
    const result = lineTestResults[getLineTestKey(channel)];
    if (!result) return '';
    if (result.status === 'testing') return '测速中';
    if (result.status === 'fail') return '不可用';
    return formatLineSpeedCompact(result.speedKBps) || '可用';
  };

  const getBestTestedLine = (channels: LiveChannel[]) => {
    const okChannels = channels
      .map((channel) => ({ channel, result: lineTestResults[getLineTestKey(channel)] }))
      .filter((item): item is { channel: LiveChannel; result: LiveLineTestResult } => item.result?.status === 'ok');

    if (okChannels.length === 0) return null;

    return okChannels.sort((a, b) => {
      const speedDiff = (b.result.speedKBps || 0) - (a.result.speedKBps || 0);
      if (Math.abs(speedDiff) > 1) return speedDiff;
      return (a.result.firstByteMs || Number.MAX_SAFE_INTEGER) - (b.result.firstByteMs || Number.MAX_SAFE_INTEGER);
    })[0].channel;
  };

  // 从本次测速的即时结果中选出最优线路（不依赖异步 state，供「测速并选择推荐线路」使用）
  const getBestChannelFromResults = (channels: LiveChannel[], results: Record<string, LiveLineTestResult>) => {
    const okChannels = channels
      .map((channel) => ({ channel, result: results[getLineTestKey(channel)] }))
      .filter((item): item is { channel: LiveChannel; result: LiveLineTestResult } => item.result?.status === 'ok');

    if (okChannels.length === 0) return null;

    return okChannels.sort((a, b) => {
      const speedDiff = (b.result.speedKBps || 0) - (a.result.speedKBps || 0);
      if (Math.abs(speedDiff) > 1) return speedDiff;
      return (a.result.firstByteMs || Number.MAX_SAFE_INTEGER) - (b.result.firstByteMs || Number.MAX_SAFE_INTEGER);
    })[0].channel;
  };

  const getPreferredLine = (channels: LiveChannel[]) => {
    if (!channels || channels.length === 0) return null;
    const activeLine = currentChannel ? channels.find((channel) => channel.id === currentChannel.id) : null;
    return activeLine || getBestTestedLine(channels) || channels[0];
  };

  const getItemChannels = (item: MergedChannelItem) => {
    return item.type === 'single' ? [item.channel] : item.channels;
  };

  const isTestingLineGroup = (channels: LiveChannel[]) => {
    return channels.some((channel) => {
      const key = getLineTestKey(channel);
      // 同步锁优先，避免自动/手动在同一帧内重复测同一条线路
      return inFlightKeysRef.current.has(key) || lineTestResults[key]?.status === 'testing';
    });
  };

  // 复用或新建当前测速会话的中断控制器（已中断则重建）
  const ensureTestSignal = () => {
    if (!testAbortRef.current || testAbortRef.current.signal.aborted) {
      testAbortRef.current = new AbortController();
    }
    return testAbortRef.current.signal;
  };

  // 中断当前所有测速（自动 + 手动）
  const abortLiveTests = () => {
    testAbortRef.current?.abort();
    testAbortRef.current = null;
  };

  // 更新测速结果（同时同步 ref，供 handleTestLines 内部同步读取）
  const commitTestResults = (next: Record<string, LiveLineTestResult>) => {
    lineTestResultsRef.current = next;
    setLineTestResults(next);
  };

  const testLineGroup = (event: React.MouseEvent, channels: LiveChannel[]) => {
    event.stopPropagation();
    if (isTestingLineGroup(channels)) return;
    handleTestLines(channels, ensureTestSignal());
  };

  // 测速并自动切换到推荐（最优）线路
  const testAndPickLineGroup = (event: React.MouseEvent, channels: LiveChannel[], mergedKey?: string) => {
    event.stopPropagation();
    if (isTestingLineGroup(channels)) return;
    handleTestAndPlayLines(channels, mergedKey);
  };

  const iconButtonClassName = (disabled: boolean, active = false) => (
    `inline-flex h-7 w-7 items-center justify-center rounded-md border flex-shrink-0 transition-colors ${disabled
      ? 'border-gray-200 dark:border-gray-700 text-gray-400 dark:text-gray-600 cursor-not-allowed opacity-60'
      : active
        ? 'border-green-500 text-green-600 dark:border-green-500 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20'
        : 'border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:border-green-500 hover:text-green-600 dark:hover:border-green-500 dark:hover:text-green-400'
    }`
  );

  const resolveClientUrl = (baseUrl: string, relativePath: string) => {
    try {
      if (/^https?:\/\//i.test(relativePath)) return relativePath;
      if (relativePath.startsWith('//')) {
        const base = new URL(baseUrl, window.location.href);
        return `${base.protocol}${relativePath}`;
      }
      return new URL(relativePath, new URL(baseUrl, window.location.href)).href;
    } catch {
      return relativePath;
    }
  };

  const findFirstPlayableLine = (content: string) => {
    return content
      .split('\n')
      .map((line) => line.trim())
      .find((line) => line && !line.startsWith('#')) || '';
  };

  const getClientTestUrl = (rawUrl: string, source?: LiveSource | null) => {
    const proxyMode = source?.proxyMode || 'full';
    const lower = rawUrl.toLowerCase();
    const path = lower.split('?')[0];
    const isM3u = path.endsWith('.m3u8') || path.endsWith('.m3u') || lower.includes('.m3u8') || lower.includes('.m3u');
    const isProgressive = path.endsWith('.flv') || path.endsWith('.mp4') || lower.includes('.flv?') || lower.includes('.mp4?');

    if (isProgressive || proxyMode === 'direct') return rawUrl;

    // 和实际播放链路保持一致：full 测代理后的分片，m3u8-only 测直连分片。
    if (isM3u || !isProgressive) {
      return `/api/proxy/m3u8?url=${encodeURIComponent(rawUrl)}&moontv-source=${encodeURIComponent(source?.key || '')}${proxyMode === 'm3u8-only' ? '&allowCORS=true' : ''}`;
    }

    return rawUrl;
  };

  const fetchTextByClient = async (url: string, signal: AbortSignal) => {
    const startedAt = performance.now();
    const response = await fetch(url, { cache: 'no-store', signal });
    const firstByteMs = performance.now() - startedAt;
    if (!response.ok) {
      response.body?.cancel();
      throw new Error(`HTTP ${response.status}`);
    }
    const text = await response.text();
    return { text, finalUrl: response.url || url, firstByteMs };
  };

  const sampleByClient = async (url: string, signal: AbortSignal) => {
    const startedAt = performance.now();
    const response = await fetch(url, { cache: 'no-store', signal });
    if (!response.ok) {
      response.body?.cancel();
      throw new Error(`HTTP ${response.status}`);
    }
    if (!response.body) throw new Error('empty body');

    const reader = response.body.getReader();
    let firstByteAt = 0;
    let bytesRead = 0;
    const sampleBytes = 512 * 1024;

    try {
      while (bytesRead < sampleBytes) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value?.byteLength) {
          if (!firstByteAt) firstByteAt = performance.now();
          bytesRead += value.byteLength;
        }
      }
    } finally {
      try {
        reader.releaseLock();
      } catch {
        // ignore
      }
      try {
        response.body.cancel();
      } catch {
        // ignore
      }
    }

    const endedAt = performance.now();
    const firstByteMs = (firstByteAt || endedAt) - startedAt;
    const transferMs = Math.max(1, endedAt - (firstByteAt || startedAt));
    const speedKBps = bytesRead > 0 ? (bytesRead / 1024) / (transferMs / 1000) : 0;

    return {
      firstByteMs: Math.round(firstByteMs),
      speedKBps: Math.round(speedKBps * 10) / 10,
      bytesRead,
    };
  };

  const testLiveLine = async (channel: LiveChannel, externalSignal?: AbortSignal): Promise<LiveLineTestResult> => {
    const controller = new AbortController();
    // 外部中断（如切换分组）时立即终止本条测速
    const onExternalAbort = () => controller.abort();
    if (externalSignal) {
      if (externalSignal.aborted) controller.abort();
      else externalSignal.addEventListener('abort', onExternalAbort, { once: true });
    }
    const timeout = window.setTimeout(() => controller.abort(), 10000);
    const source = currentSourceRef.current || currentSource;
    const testUrl = getClientTestUrl(channel.url, source);
    const lowerTestUrl = testUrl.toLowerCase();

    try {
      const shouldTreatAsM3u8 =
        lowerTestUrl.includes('.m3u') ||
        lowerTestUrl.includes('/api/proxy/m3u8');

      if (shouldTreatAsM3u8) {
        const manifest = await fetchTextByClient(testUrl, controller.signal);
        let mediaLine = findFirstPlayableLine(manifest.text);
        if (!mediaLine) throw new Error('empty m3u8');

        let mediaUrl = resolveClientUrl(manifest.finalUrl, mediaLine);

        if (manifest.text.includes('#EXT-X-STREAM-INF') || mediaUrl.toLowerCase().includes('.m3u')) {
          const child = await fetchTextByClient(mediaUrl, controller.signal);
          mediaLine = findFirstPlayableLine(child.text);
          if (!mediaLine) throw new Error('empty child m3u8');
          mediaUrl = resolveClientUrl(child.finalUrl, mediaLine);
        }

        const sample = await sampleByClient(mediaUrl, controller.signal);
        return {
          status: 'ok',
          type: 'm3u8',
          firstByteMs: Math.round(manifest.firstByteMs + sample.firstByteMs),
          speedKBps: sample.speedKBps,
          bytesRead: sample.bytesRead,
          testedAt: Date.now(),
        };
      }

      const sample = await sampleByClient(testUrl, controller.signal);
      return {
        status: 'ok',
        type: lowerTestUrl.includes('.flv') ? 'flv' : lowerTestUrl.includes('.mp4') ? 'mp4' : 'unknown',
        firstByteMs: sample.firstByteMs,
        speedKBps: sample.speedKBps,
        bytesRead: sample.bytesRead,
        testedAt: Date.now(),
      };
    } catch (error) {
      return {
        status: 'fail',
        type: 'unknown',
        firstByteMs: 0,
        speedKBps: 0,
        bytesRead: 0,
        testedAt: Date.now(),
        error: error instanceof Error ? error.message : '客户端测速失败',
      };
    } finally {
      window.clearTimeout(timeout);
      externalSignal?.removeEventListener('abort', onExternalAbort);
    }
  };

  const handleTestLines = async (
    channels: LiveChannel[],
    signal?: AbortSignal,
    skipCompleted = false
  ): Promise<Record<string, LiveLineTestResult>> => {
    if (!channels.length) return {};

    const pendingChannels = channels;
    const results: Record<string, LiveLineTestResult> = {};

    // 中断时清理尚未出结果的「测速中」状态，避免 UI 卡在加载中
    const clearPendingTesting = () => {
      const next = { ...lineTestResultsRef.current };
      pendingChannels.forEach((channel) => {
        const key = getLineTestKey(channel);
        if (next[key]?.status === 'testing') {
          delete next[key];
        }
      });
      commitTestResults(next);
    };

    if (signal?.aborted) return results;

    // 每 5 个一组并发测速，一组测完再测下一组
    const batchSize = 5;
    const runBatch = async (batch: LiveChannel[]) => {
      const startedAt = Date.now();
      // 只把真正开始测的这一组标记为「测速中」，尚未轮到的线路保持可手动测
      const next = { ...lineTestResultsRef.current };
      batch.forEach((channel) => {
        const key = getLineTestKey(channel);
        next[key] = { status: 'testing', testedAt: startedAt };
        inFlightKeysRef.current.add(key);
      });
      commitTestResults(next);

      await Promise.all(
        batch.map(async (channel) => {
          const key = getLineTestKey(channel);
          try {
            const result = await testLiveLine(channel, signal);
            // 已被中断则丢弃本条结果
            if (signal?.aborted) return;
            results[key] = result;
            commitTestResults({ ...lineTestResultsRef.current, [key]: result });
          } catch (error) {
            if (signal?.aborted) return;
            const failResult: LiveLineTestResult = {
              status: 'fail',
              testedAt: Date.now(),
              error: error instanceof Error ? error.message : '测速失败',
            };
            results[key] = failResult;
            commitTestResults({
              ...lineTestResultsRef.current,
              [key]: failResult,
            });
          } finally {
            inFlightKeysRef.current.delete(key);
          }
        })
      );
    };

    for (let i = 0; i < pendingChannels.length; i += batchSize) {
      if (signal?.aborted) break;
      const batch = pendingChannels.slice(i, i + batchSize).filter((channel) => {
        const key = getLineTestKey(channel);
        // 正被其它测速任务测的线路跳过，避免重复
        if (inFlightKeysRef.current.has(key)) return false;
        // 自动测速跳过已出结果的线路（手动可以刷新重测）
        if (skipCompleted) {
          const status = lineTestResultsRef.current[key]?.status;
          if (status === 'ok' || status === 'fail') return false;
        }
        return true;
      });
      if (!batch.length) continue;
      await runBatch(batch);
    }

    if (signal?.aborted) {
      clearPendingTesting();
    }

    return results;
  };

  // 测速完成后自动播放评分最高的线路
  const handleTestAndPlayLines = async (channels: LiveChannel[], mergedKey?: string) => {
    if (!channels.length) return;
    const results = await handleTestLines(channels, ensureTestSignal());
    const best = getBestChannelFromResults(channels, results);
    if (best) {
      // 展开合并频道，让用户看到被选中的推荐线路
      if (mergedKey) {
        setExpandedMergedChannels((prev) => (
          prev.includes(mergedKey) ? prev : [...prev, mergedKey]
        ));
      }
      handleChannelChange(best);
    }
  };

  const handlePlayLines = (channels: LiveChannel[]) => {
    const preferred = getPreferredLine(channels);
    if (preferred) handleChannelChange(preferred);
  };

  // 读取「电视直播自动测速」开关，并监听设置面板的变更广播
  useEffect(() => {
    setLiveAutoSpeedTest(isLiveAutoSpeedTestEnabled());
    const handler = (event: Event) => {
      const detail = (event as CustomEvent<{ enabled?: boolean }>).detail;
      setLiveAutoSpeedTest(
        typeof detail?.enabled === 'boolean'
          ? detail.enabled
          : isLiveAutoSpeedTestEnabled()
      );
    };
    window.addEventListener('liveAutoSpeedTestChanged', handler);
    return () =>
      window.removeEventListener('liveAutoSpeedTestChanged', handler);
  }, []);

  // 切换直播源时重置自动测速记录，避免把旧源的测速结果错记到新源
  useEffect(() => {
    autoTestedGroupRef.current = '';
    // 切换直播源立即中断在跑的所有测速（自动 + 手动）
    abortLiveTests();
  }, [currentSource?.key]);

  // 开启自动测速后，自动测速当前分组下的线路
  useEffect(() => {
    if (!liveAutoSpeedTest) {
      autoTestedGroupRef.current = '';
      abortLiveTests();
      return;
    }
    if (!selectedGroup || isSwitchingSource) return;
    const channels = groupedChannels[selectedGroup];
    if (!channels || channels.length === 0) return;

    const groupKey = `${currentSource?.key || ''}:${selectedGroup}`;
    if (autoTestedGroupRef.current === groupKey) return;
    autoTestedGroupRef.current = groupKey;

    // 开始新分组的测速（跳过已出结果的线路），共用当前会话以便切换分组时统一中断
    handleTestLines(channels, ensureTestSignal(), true);

    return () => {
      abortLiveTests();
    };
  }, [
    liveAutoSpeedTest,
    selectedGroup,
    groupedChannels,
    currentSource,
    isSwitchingSource,
  ]);

  // 组件卸载时中断在跑的测速
  useEffect(() => () => {
    abortLiveTests();
    inFlightKeysRef.current.clear();
  }, []);

  // 切换分组
  const handleGroupChange = (group: string) => {
    // 如果正在切换直播源，则禁用分组切换
    if (isSwitchingSource) return;

    // 切换分组立即中断上一分组正在进行的测速（自动 + 手动）
    abortLiveTests();
    autoTestedGroupRef.current = '';

    setSelectedGroup(group);
    const filtered = filterChannels(group, searchKeyword);
    setFilteredChannels(filtered);

    // 如果当前选中的频道在新的分组中，自动滚动到该频道位置
    if (currentChannel && filtered.some(channel => channel.id === currentChannel.id)) {
      setTimeout(() => {
        scrollToChannel(currentChannel);
      }, 100);
    } else {
      // 否则滚动到频道列表顶端
      if (channelListRef.current) {
        channelListRef.current.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      }
    }
  };

  // 处理搜索
  const handleSearch = (keyword: string) => {
    setSearchKeyword(keyword);

    if (!selectedGroup) return;

    // 先在当前分组搜索
    const filtered = filterChannels(selectedGroup, keyword);

    // 如果当前分组没有匹配的频道，且有搜索关键词，轮询所有分组
    if (filtered.length === 0 && keyword.trim() && groupedChannels) {
      const groups = Object.keys(groupedChannels);

      // 轮询所有分组，找到第一个有匹配频道的分组
      for (const group of groups) {
        const groupFiltered = filterChannels(group, keyword);
        if (groupFiltered.length > 0) {
          // 找到有匹配频道的分组，自动切换
          setSelectedGroup(group);
          setFilteredChannels(groupFiltered);

          // 滚动到频道列表顶端
          if (channelListRef.current) {
            channelListRef.current.scrollTo({
              top: 0,
              behavior: 'smooth'
            });
          }

          return;
        }
      }
    }

    // 如果当前分组有匹配的频道，或者所有分组都没有匹配的频道，使用当前分组的结果
    setFilteredChannels(filtered);
  };

  // 切换收藏
  const handleToggleFavorite = async () => {
    if (!currentSourceRef.current || !currentChannelRef.current) return;

    try {
      const currentFavorited = favoritedRef.current;
      const newFavorited = !currentFavorited;

      // 立即更新状态
      setFavorited(newFavorited);
      favoritedRef.current = newFavorited;

      // 异步执行收藏操作
      try {
        if (newFavorited) {
          // 如果未收藏，添加收藏
          await saveFavorite(`live_${currentSourceRef.current.key}`, `live_${currentChannelRef.current.id}`, {
            title: currentChannelRef.current.name,
            source_name: currentSourceRef.current.name,
            year: '',
            cover: getLogoUrl(currentChannelRef.current.logo, currentSourceRef.current.key),
            total_episodes: 1,
            save_time: Date.now(),
            search_title: '',
            origin: 'live',
          });
        } else {
          // 如果已收藏，删除收藏
          await deleteFavorite(`live_${currentSourceRef.current.key}`, `live_${currentChannelRef.current.id}`);
        }
      } catch (err) {
        console.error('收藏操作失败:', err);
        // 如果操作失败，回滚状态
        setFavorited(currentFavorited);
        favoritedRef.current = currentFavorited;
      }
    } catch (err) {
      console.error('切换收藏失败:', err);
    }
  };

  // 检测WebGPU支持
  useEffect(() => {
    const checkWebGPUSupport = async () => {
      if (typeof navigator === 'undefined' || !('gpu' in navigator)) {
        setWebGPUSupported(false);
        console.log('WebGPU不支持：浏览器不支持WebGPU API');
        return;
      }

      try {
        const adapter = await (navigator as any).gpu.requestAdapter();
        if (!adapter) {
          setWebGPUSupported(false);
          console.log('WebGPU不支持：无法获取GPU适配器');
          return;
        }

        setWebGPUSupported(true);
        console.log('WebGPU支持检测：✅ 支持');
      } catch (err) {
        setWebGPUSupported(false);
        console.log('WebGPU不支持：', err);
      }
    };

    checkWebGPUSupport();
  }, []);

  // 初始化
  useEffect(() => {
    fetchLiveSources();
  }, []);

  // 检查收藏状态
  useEffect(() => {
    if (!currentSource || !currentChannel) return;
    (async () => {
      try {
        const fav = await checkIsFavorited(`live_${currentSource.key}`, `live_${currentChannel.id}`);
        setFavorited(fav);
        favoritedRef.current = fav;
      } catch (err) {
        console.error('检查收藏状态失败:', err);
      }
    })();
  }, [currentSource, currentChannel]);

  // 监听收藏数据更新事件
  useEffect(() => {
    if (!currentSource || !currentChannel) return;

    const unsubscribe = subscribeToDataUpdates(
      'favoritesUpdated',
      (favorites: Record<string, any>) => {
        const key = generateStorageKey(`live_${currentSource.key}`, `live_${currentChannel.id}`);
        const isFav = !!favorites[key];
        setFavorited(isFav);
        favoritedRef.current = isFav;
      }
    );

    return unsubscribe;
  }, [currentSource, currentChannel]);

  // 当分组切换时，将激活的分组标签滚动到视口中间
  useEffect(() => {
    if (!selectedGroup || !groupContainerRef.current || !groupedChannels) return;

    const groupKeys = Object.keys(groupedChannels);
    const groupIndex = groupKeys.indexOf(selectedGroup);
    if (groupIndex === -1) return;

    const btn = groupButtonRefs.current?.[groupIndex];
    const container = groupContainerRef.current;
    if (btn && container) {
      // 手动计算滚动位置，只滚动分组标签容器
      const containerRect = container.getBoundingClientRect();
      const btnRect = btn.getBoundingClientRect();
      const scrollLeft = container.scrollLeft;

      // 计算按钮相对于容器的位置
      const btnLeft = btnRect.left - containerRect.left + scrollLeft;
      const btnWidth = btnRect.width;
      const containerWidth = containerRect.width;

      // 计算目标滚动位置，使按钮居中
      const targetScrollLeft = btnLeft - (containerWidth - btnWidth) / 2;

      // 平滑滚动到目标位置
      container.scrollTo({
        left: targetScrollLeft,
        behavior: 'smooth',
      });
    }
  }, [selectedGroup, groupedChannels]);

  function m3u8Loader(video: HTMLVideoElement, url: string) {
    if (!Hls) {
      console.error('HLS.js 未加载');
      return;
    }

    class CustomHlsJsLoader extends Hls.DefaultConfig.loader {
      constructor(config: any) {
        super(config);
        const load = this.load.bind(this);
        this.load = function (context: any, config: any, callbacks: any) {
          // 判断当前直播源的代理模式
          const currentLiveSource = currentSourceRef.current;
          const proxyMode = currentLiveSource?.proxyMode || 'full';

          // 拦截manifest和level请求
          if (
            (context as any).type === 'manifest' ||
            (context as any).type === 'level'
          ) {
            // manifest 请求处理
            if ((context as any).type === 'manifest') {
              if (proxyMode === 'full') {
                // 全量代理：添加 source 参数
                try {
                  const url = new URL(context.url);
                  url.searchParams.set('moontv-source', currentSourceRef.current?.key || '');
                  context.url = url.toString();
                } catch (error) {
                  // ignore
                }
              } else if (proxyMode === 'm3u8-only') {
                // 仅代理m3u8模式：添加 source 参数和 allowCORS 参数
                try {
                  const url = new URL(context.url);
                  url.searchParams.set('moontv-source', currentSourceRef.current?.key || '');
                  url.searchParams.set('allowCORS', 'true');
                  context.url = url.toString();
                } catch (error) {
                  context.url = context.url + '&allowCORS=true';
                }
              }
              // direct 模式：直接使用原始 URL，不添加任何参数
            }

            // level 请求（ts 分片）处理
            if ((context as any).type === 'level') {
              if (proxyMode === 'full') {
                // 全量代理：添加 source 参数
                try {
                  const url = new URL(context.url);
                  url.searchParams.set('moontv-source', currentSourceRef.current?.key || '');
                  context.url = url.toString();
                } catch (error) {
                  // ignore
                }
              }
              // m3u8-only 模式：ts 分片 URL 已经被代理服务器重写为原始 URL，不需要添加参数
              // direct 模式：ts 分片直接使用原始 URL，不添加任何参数
            }
          }
          // 执行原始load方法
          load(context, config, callbacks);
        };
      }
    }

    // 清理之前的 HLS 实例
    if (video.hls) {
      try {
        video.hls.destroy();
        video.hls = null;
      } catch (err) {
        console.warn('清理 HLS 实例时出错:', err);
      }
    }

    const hls = new Hls({
      debug: false,
      enableWorker: true,
      lowLatencyMode: true,
      maxBufferLength: 30,
      backBufferLength: 30,
      maxBufferSize: 60 * 1000 * 1000,
      loader: CustomHlsJsLoader,
    });

    hls.loadSource(url);
    hls.attachMedia(video);
    video.hls = hls;

    hls.on(Hls.Events.ERROR, function (event: any, data: any) {
      console.error('HLS Error:', event, data);

      if (data.fatal) {
        switch (data.type) {
          case Hls.ErrorTypes.NETWORK_ERROR:
            hls.startLoad();
            break;
          case Hls.ErrorTypes.MEDIA_ERROR:
            // hls.recoverMediaError();
            break;
          default:
            hls.destroy();
            break;
        }
      }
    });
  }

  function flvLoader(video: HTMLVideoElement, url: string) {
    if (!flvjs) {
      console.error('FLV.js 未加载');
      return;
    }

    // 清理之前的 FLV 实例
    if (video.flv) {
      try {
        if (video.flv.unload) {
          video.flv.unload();
        }
        video.flv.destroy();
        video.flv = null;
      } catch (err) {
        console.warn('清理 FLV 实例时出错:', err);
      }
    }

    const flvPlayer = flvjs.createPlayer({
      type: 'flv',
      url,
      isLive: true
    });
    flvPlayer.attachMediaElement(video);
    flvPlayer.on(flvjs.Events.ERROR, (errorType: string, errorDetail: string) => {
      console.error('FLV.js error:', errorType, errorDetail);
    });
    flvPlayer.load();
    video.flv = flvPlayer;
  }

  // 播放器初始化
  useEffect(() => {
    const preload = async () => {
      if (
        !Artplayer ||
        !Hls ||
        !flvjs ||
        !videoUrl ||
        !artRef.current ||
        !currentChannel
      ) {
        return;
      }

      console.log('视频URL:', videoUrl);

      // 销毁之前的播放器实例并创建新的
      if (artPlayerRef.current) {
        cleanupPlayer();
      }

      // precheck type
      let type = 'm3u8';
      const proxyMode = currentSourceRef.current?.proxyMode || 'full';

      // 直连模式：跳过服务器预检查，直接使用 m3u8
      if (proxyMode === 'direct') {
        type = 'm3u8';
      } else {
        // 全量代理或仅代理m3u8：通过服务器预检查
        try {
          const precheckUrl = `/api/live/precheck?url=${encodeURIComponent(videoUrl)}&moontv-source=${currentSourceRef.current?.key || ''}`;
          const precheckResponse = await fetch(precheckUrl);
          if (!precheckResponse.ok) {
            console.error('预检查失败:', precheckResponse.statusText);
            setIsVideoLoading(false);
            return;
          }
          const precheckResult = await precheckResponse.json();
          if (precheckResult?.success && precheckResult?.type) {
            type = precheckResult.type;
          } else {
            console.error('预检查返回无效结果:', precheckResult);
            setIsVideoLoading(false);
            return;
          }
        } catch (err) {
          console.error('预检查异常:', err);
          setIsVideoLoading(false);
          return;
        }
      }

      // 如果不是 m3u8、flv 或 mp4 类型，设置不支持的类型并返回
      if (type !== 'm3u8' && type !== 'flv' && type !== 'mp4') {
        setUnsupportedType(type);
        setIsVideoLoading(false);
        return;
      }

      // 重置不支持的类型
      setUnsupportedType(null);

      const customType = { m3u8: m3u8Loader, flv: flvLoader };

      // 根据代理模式决定 URL
      let targetUrl = videoUrl;
      if (type === 'm3u8') {
        if (proxyMode === 'direct') {
          // 直连模式：直接使用原始 URL
          targetUrl = videoUrl;
        } else {
          // 全量代理或仅代理m3u8：使用代理 URL
          targetUrl = `/api/proxy/m3u8?url=${encodeURIComponent(videoUrl)}&moontv-source=${currentSourceRef.current?.key || ''}`;
        }
      }

      try {
        // 创建新的播放器实例
        Artplayer.USE_RAF = true;

        artPlayerRef.current = new Artplayer({
          container: artRef.current,
          url: targetUrl,
          poster: currentChannel.logo,
          volume: 0.7,
          isLive: true, // 设置为直播模式
          muted: false,
          autoplay: true,
          pip: true,
          autoSize: false,
          autoMini: false,
          screenshot: false,
          setting: true,
          loop: false,
          flip: true,
          playbackRate: false,
          aspectRatio: false,
          fullscreen: true,
          fullscreenWeb: true,
          subtitleOffset: false,
          miniProgressBar: false,
          mutex: true,
          playsInline: true,
          autoPlayback: false,
          airplay: true,
          theme: '#22c55e',
          lang: 'zh-cn',
          hotkey: false,
          fastForward: false, // 直播不需要快进
          autoOrientation: true,
          lock: true,
          moreVideoAttr: {
            crossOrigin: 'anonymous',
            preload: 'metadata',
          },
          type: type,
          customType: customType,
          icons: {
            loading:
              '<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MCIgaGVpZ2h0PSI1MCIgdmlld0JveD0iMCAwIDUwIDUwIj48cGF0aCBkPSJNMjUuMjUxIDYuNDYxYy0xMC4zMTggMC0xOC42ODMgOC4zNjUtMTguNjgzIDE4LjY4M2g0LjA2OGMwLTguMDcgNi41NDUtMTQuNjE1IDE0LjYxNS0xNC42MTVWNi40NjF6IiBmaWxsPSIjMDA5Njg4Ij48YW5pbWF0ZVRyYW5zZm9ybSBhdHRyaWJ1dGVOYW1lPSJ0cmFuc2Zvcm0iIGF0dHJpYnV0ZVR5cGU9IlhNTCIgZHVyPSIxcyIgZnJvbT0iMCAyNSAyNSIgcmVwZWF0Q291bnQ9ImluZGVmaW5pdGUiIHRvPSIzNjAgMjUgMjUiIHR5cGU9InJvdGF0ZSIvPjwvcGF0aD48L3N2Zz4=">',
          },
          settings: [
            ...(webGPUSupported ? [
              {
                name: 'Anime4K超分',
                html: 'Anime4K超分',
                icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5zm0 18c-4 0-7-3-7-7V9l7-3.5L19 9v4c0 4-3 7-7 7z" fill="#ffffff"/><path d="M10 12l2 2 4-4" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                switch: anime4kEnabledRef.current,
                onSwitch: async function (item: any) {
                  const newVal = !item.switch;
                  const result = await toggleAnime4K(newVal);
                  return result;
                },
              },
              {
                name: '超分模式',
                html: '超分模式',
                selector: [
                  {
                    html: 'ModeA (快速)',
                    value: 'ModeA',
                    default: anime4kModeRef.current === 'ModeA',
                  },
                  {
                    html: 'ModeB (平衡)',
                    value: 'ModeB',
                    default: anime4kModeRef.current === 'ModeB',
                  },
                  {
                    html: 'ModeC (质量)',
                    value: 'ModeC',
                    default: anime4kModeRef.current === 'ModeC',
                  },
                  {
                    html: 'ModeAA (增强快速)',
                    value: 'ModeAA',
                    default: anime4kModeRef.current === 'ModeAA',
                  },
                  {
                    html: 'ModeBB (增强平衡)',
                    value: 'ModeBB',
                    default: anime4kModeRef.current === 'ModeBB',
                  },
                  {
                    html: 'ModeCA (最高质量)',
                    value: 'ModeCA',
                    default: anime4kModeRef.current === 'ModeCA',
                  },
                ],
                onSelect: async function (item: any) {
                  await changeAnime4KMode(item.value);
                  return item.html;
                },
              },
              {
                name: '超分倍数',
                html: '超分倍数',
                selector: [
                  {
                    html: '1.5x',
                    value: '1.5',
                    default: anime4kScaleRef.current === 1.5,
                  },
                  {
                    html: '2.0x',
                    value: '2.0',
                    default: anime4kScaleRef.current === 2.0,
                  },
                  {
                    html: '3.0x',
                    value: '3.0',
                    default: anime4kScaleRef.current === 3.0,
                  },
                  {
                    html: '4.0x',
                    value: '4.0',
                    default: anime4kScaleRef.current === 4.0,
                  },
                ],
                onSelect: async function (item: any) {
                  await changeAnime4KScale(parseFloat(item.value));
                  return item.html;
                },
              }
            ] : []),
          ],
        });

        artPlayerRef.current.on('flip', syncAnime4KCanvasFlip);

        // 监听播放器事件
        artPlayerRef.current.on('ready', () => {
          setError(null);
          setIsVideoLoading(false);

        });

        artPlayerRef.current.on('loadstart', () => {
          setIsVideoLoading(true);
        });

        artPlayerRef.current.on('loadeddata', () => {
          setIsVideoLoading(false);
        });

        artPlayerRef.current.on('canplay', () => {
          setIsVideoLoading(false);
        });

        artPlayerRef.current.on('waiting', () => {
          setIsVideoLoading(true);
        });

        artPlayerRef.current.on('error', (err: any) => {
          console.error('播放器错误:', err);
        });

        if (artPlayerRef.current?.video) {
          ensureVideoSource(
            artPlayerRef.current.video as HTMLVideoElement,
            targetUrl
          );
        }

      } catch (err) {
        console.error('创建播放器失败:', err);
        // 不设置错误，只记录日志
      }
    }
    preload();
  }, [Artplayer, Hls, videoUrl, currentChannel, loading]);

  // 清理播放器资源
  useEffect(() => {
    return () => {
      cleanupPlayer();
    };
  }, []);

  // 页面卸载时的额外清理
  useEffect(() => {
    const handleBeforeUnload = () => {
      cleanupPlayer();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      cleanupPlayer();
    };
  }, []);

  // 全局快捷键处理
  useEffect(() => {
    const handleKeyboardShortcuts = (e: KeyboardEvent) => {
      // 忽略输入框中的按键事件
      if (
        (e.target as HTMLElement).tagName === 'INPUT' ||
        (e.target as HTMLElement).tagName === 'TEXTAREA'
      )
        return;

      // 上箭头 = 音量+
      if (e.key === 'ArrowUp') {
        if (artPlayerRef.current && artPlayerRef.current.volume < 1) {
          artPlayerRef.current.volume =
            Math.round((artPlayerRef.current.volume + 0.1) * 10) / 10;
          artPlayerRef.current.notice.show = `音量: ${Math.round(
            artPlayerRef.current.volume * 100
          )}`;
          e.preventDefault();
        }
      }

      // 下箭头 = 音量-
      if (e.key === 'ArrowDown') {
        if (artPlayerRef.current && artPlayerRef.current.volume > 0) {
          artPlayerRef.current.volume =
            Math.round((artPlayerRef.current.volume - 0.1) * 10) / 10;
          artPlayerRef.current.notice.show = `音量: ${Math.round(
            artPlayerRef.current.volume * 100
          )}`;
          e.preventDefault();
        }
      }

      // 空格 = 播放/暂停
      if (e.key === ' ') {
        if (artPlayerRef.current) {
          artPlayerRef.current.toggle();
          e.preventDefault();
        }
      }

      // f 键 = 切换全屏
      if (e.key === 'f' || e.key === 'F') {
        if (artPlayerRef.current) {
          artPlayerRef.current.fullscreen = !artPlayerRef.current.fullscreen;
          e.preventDefault();
        }
      }
    };

    document.addEventListener('keydown', handleKeyboardShortcuts);
    return () => {
      document.removeEventListener('keydown', handleKeyboardShortcuts);
    };
  }, []);

  // 初始化加载样式的步骤模型
  const activeLiveStepIdx = Math.max(
    0,
    LIVE_LOADING_STEPS.indexOf(loadingStage as LiveLoadingStepKey)
  );
  // 方格/符阵不出现 emoji：阶段语义由描边图标承担，文案只留纯中文
  const plainLoadingMessage = loadingMessage
    .replace(/^[^一-龥]+/, '')
    .replace(/[\s.．。]+$/, '');
  // 播放器蒙层只有个布尔量，没有子阶段可跟，固定停在「加载」这一格
  const playerStepIdx = 0;

  if (loading) {
    return (
      <PageLayout activePath='/live'>
        {/* fixed 铺满视口：main 在移动端有 3rem 顶距和底部安全区，
            用 min-h-screen 会把内容整体压到视口中心偏下 */}
        <div className='mtv-load-overlay fixed inset-0 flex items-center justify-center pointer-events-none'>
          <div className='text-center max-w-md mx-auto px-6'>
            {/* 三种加载款式（旧版那一套各页自备） */}
            <LoadingStyle
              steps={LIVE_LOADING_STEPS.map((k) => LIVE_LOADING_STEP_META[k])}
              activeStepIdx={activeLiveStepIdx}
              message={plainLoadingMessage}
              legacy={
                <>
                  {/* 动画直播图标 */}
                  <div className='relative mb-8'>
                    <div className='relative mx-auto w-24 h-24 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl shadow-2xl flex items-center justify-center transform hover:scale-105 transition-transform duration-300'>
                      <div className='text-white text-4xl'>📺</div>
                      {/* 旋转光环 */}
                      <div className='absolute -inset-2 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl opacity-20 animate-spin'></div>
                    </div>

                    {/* 浮动粒子效果 */}
                    <div className='absolute top-0 left-0 w-full h-full pointer-events-none'>
                      <div className='absolute top-2 left-2 w-2 h-2 bg-green-400 rounded-full animate-bounce'></div>
                      <div
                        className='absolute top-4 right-4 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce'
                        style={{ animationDelay: '0.5s' }}
                      ></div>
                      <div
                        className='absolute bottom-3 left-6 w-1 h-1 bg-lime-400 rounded-full animate-bounce'
                        style={{ animationDelay: '1s' }}
                      ></div>
                    </div>
                  </div>

                  {/* 进度指示器 */}
                  <div className='mb-6 w-80 mx-auto'>
                    <div className='flex justify-center space-x-2 mb-4'>
                      <div
                        className={`w-3 h-3 rounded-full transition-all duration-500 ${loadingStage === 'loading' ? 'bg-green-500 scale-125' : 'bg-green-500'
                          }`}
                      ></div>
                      <div
                        className={`w-3 h-3 rounded-full transition-all duration-500 ${loadingStage === 'fetching' ? 'bg-green-500 scale-125' : 'bg-green-500'
                          }`}
                      ></div>
                      <div
                        className={`w-3 h-3 rounded-full transition-all duration-500 ${loadingStage === 'ready' ? 'bg-green-500 scale-125' : 'bg-gray-300'
                          }`}
                      ></div>
                    </div>

                    {/* 进度条 */}
                    <div className='w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden'>
                      <div
                        className='h-full bg-gradient-to-r from-green-500 to-emerald-600 rounded-full transition-all duration-1000 ease-out'
                        style={{
                          width:
                            loadingStage === 'loading' ? '33%' : loadingStage === 'fetching' ? '66%' : '100%',
                        }}
                      ></div>
                    </div>
                  </div>

                  {/* 加载消息 */}
                  <div className='space-y-2'>
                    <p className='text-xl font-semibold text-gray-800 dark:text-gray-200 animate-pulse'>
                      {loadingMessage}
                    </p>
                  </div>
                </>
              }
            />
          </div>
        </div>
      </PageLayout>
    );
  }

  if (error) {
    return (
      <PageLayout activePath='/live'>
        <div className='flex items-center justify-center min-h-screen bg-transparent'>
          <div className='text-center max-w-md mx-auto px-6'>
            {/* 错误图标 */}
            <div className='relative mb-8'>
              {/* 三种失败款式（旧版那一套各页自备） */}
              <LoadingErrorStyle
                steps={LIVE_LOADING_STEPS.map((k) => LIVE_LOADING_STEP_META[k])}
                activeStepIdx={activeLiveStepIdx}
                message={error}
                legacy={
                  <>
                    <div className='relative mx-auto w-24 h-24 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl shadow-2xl flex items-center justify-center transform hover:scale-105 transition-transform duration-300'>
                      <div className='text-white text-4xl'>😵</div>
                      {/* 脉冲效果 */}
                      <div className='absolute -inset-2 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl opacity-20 animate-pulse'></div>
                    </div>
                  </>
                }
              />
            </div>

            {/* 错误信息 */}
            <div className='space-y-4 mb-8'>
              <h2 className='text-2xl font-bold text-gray-800 dark:text-gray-200'>
                哎呀，出现了一些问题
              </h2>
              <div className='mtv-err-box bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4'>
                <p className='text-red-600 dark:text-red-400 font-medium'>
                  {error}
                </p>
              </div>
              <p className='text-sm text-gray-500 dark:text-gray-400'>
                请检查网络连接或尝试刷新页面
              </p>
            </div>

            {/* 操作按钮 */}
            <div className='space-y-3'>
              <button
                onClick={() => window.location.reload()}
                className='flex w-full items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-600 text-white rounded-xl font-medium hover:from-blue-600 hover:to-cyan-700 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl'
              >
                <RefreshCw className='h-4 w-4 flex-shrink-0' />
                重新尝试
              </button>
            </div>
          </div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout activePath='/live'>
      <div className='flex flex-col gap-3 py-4 px-5 lg:px-[3rem] 2xl:px-20'>
        {/* 第一行：页面标题 */}
        <div className='py-1'>
          <h1 className='text-xl font-semibold text-gray-900 dark:text-gray-100 flex items-center gap-2 max-w-[80%]'>
            <Radio className='w-5 h-5 text-blue-500 flex-shrink-0' />
            <div className='min-w-0 flex-1'>
              <div className='truncate'>
                {currentSource?.name}
                {currentSource && currentChannel && (
                  <span className='text-gray-500 dark:text-gray-400'>
                    {` > ${currentChannel.name}`}
                  </span>
                )}
                {currentSource && !currentChannel && (
                  <span className='text-gray-500 dark:text-gray-400'>
                    {` > ${currentSource.name}`}
                  </span>
                )}
              </div>
            </div>
          </h1>
        </div>

        {/* 第二行：播放器和频道列表 */}
        <div className='space-y-2'>
          {/* 折叠控制 - 仅在 lg 及以上屏幕显示 */}
          <div className='hidden lg:flex justify-end'>
            <button
              onClick={() =>
                setIsChannelListCollapsed(!isChannelListCollapsed)
              }
              className='group relative flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-white/80 hover:bg-white dark:bg-gray-800/80 dark:hover:bg-gray-800 backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/50 shadow-sm hover:shadow-md transition-all duration-200'
              title={
                isChannelListCollapsed ? '显示频道列表' : '隐藏频道列表'
              }
            >
              <svg
                className={`w-3.5 h-3.5 text-gray-500 dark:text-gray-400 transition-transform duration-200 ${isChannelListCollapsed ? 'rotate-180' : 'rotate-0'
                  }`}
                fill='none'
                stroke='currentColor'
                viewBox='0 0 24 24'
              >
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  strokeWidth='2'
                  d='M9 5l7 7-7 7'
                />
              </svg>
              <span className='text-xs font-medium text-gray-600 dark:text-gray-300'>
                {isChannelListCollapsed ? '显示' : '隐藏'}
              </span>

              {/* 精致的状态指示点 */}
              <div
                className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full transition-all duration-200 ${isChannelListCollapsed
                  ? 'bg-orange-400 animate-pulse'
                  : 'bg-green-400'
                  }`}
              ></div>
            </button>
          </div>

          <div className={`grid gap-4 lg:h-[500px] xl:h-[650px] 2xl:h-[750px] transition-all duration-300 ease-in-out ${isChannelListCollapsed
            ? 'grid-cols-1'
            : 'grid-cols-1 md:grid-cols-4'
            }`}>
            {/* 播放器 */}
            <div className={`h-full transition-all duration-300 ease-in-out ${isChannelListCollapsed ? 'col-span-1' : 'md:col-span-3'}`}>
              <div className='relative w-full h-[300px] lg:h-full'>
                <div
                  ref={artRef}
                  className='bg-black w-full h-full rounded-xl overflow-hidden shadow-lg border border-white/0 dark:border-white/30'
                ></div>

                {/* 不支持的直播类型提示 */}
                {unsupportedType && (
                  <div className='absolute inset-0 bg-black/90 backdrop-blur-sm rounded-xl overflow-hidden shadow-lg border border-white/0 dark:border-white/30 flex items-center justify-center z-[600] transition-all duration-300'>
                    <div className='text-center max-w-md mx-auto px-6'>
                      <div className='relative mb-8'>
                        <div className='relative mx-auto w-24 h-24 bg-gradient-to-r from-orange-500 to-red-600 rounded-2xl shadow-2xl flex items-center justify-center transform hover:scale-105 transition-transform duration-300'>
                          <div className='text-white text-4xl'>⚠️</div>
                          <div className='absolute -inset-2 bg-gradient-to-r from-orange-500 to-red-600 rounded-2xl opacity-20 animate-pulse'></div>
                        </div>
                      </div>
                      <div className='space-y-4'>
                        <h3 className='text-xl font-semibold text-white'>
                          暂不支持的直播流类型
                        </h3>
                        <div className='bg-orange-500/20 border border-orange-500/30 rounded-lg p-4'>
                          <p className='text-orange-300 font-medium'>
                            当前频道直播流类型：<span className='text-white font-bold'>{unsupportedType.toUpperCase()}</span>
                          </p>
                          <p className='text-sm text-orange-200 mt-2'>
                            目前仅支持 M3U8 格式的直播流
                          </p>
                        </div>
                        <p className='text-sm text-gray-300'>
                          请尝试其他频道
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* 视频加载蒙层 */}
                {isVideoLoading && (
                  <div className='absolute inset-0 bg-black/85 backdrop-blur-sm rounded-xl overflow-hidden shadow-lg border border-white/0 dark:border-white/30 flex items-center justify-center z-[500] transition-all duration-300'>
                    <div className='text-center max-w-md mx-auto px-6'>
                      {/* 三种加载款式（旧版那一套各页自备） */}
                      <LoadingStyle
                        steps={LIVE_PLAYER_STEPS}
                        activeStepIdx={playerStepIdx}
                        message='加载中'
                        onDark
                        legacy={
                          <>
                            <div className='relative mb-8'>
                              <div className='relative mx-auto w-24 h-24 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl shadow-2xl flex items-center justify-center transform hover:scale-105 transition-transform duration-300'>
                                <div className='text-white text-4xl'>📺</div>
                                <div className='absolute -inset-2 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl opacity-20 animate-spin'></div>
                              </div>
                            </div>
                            <div className='space-y-2'>
                              <p className='text-xl font-semibold text-white animate-pulse'>
                                🔄 IPTV 加载中...
                              </p>
                            </div>
                          </>
                        }
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* 外部播放器按钮 - 观影室同步状态下隐藏 */}
              {videoUrl && !liveSync.isInRoom && (
                <div className='mt-3 px-2 lg:flex-shrink-0 flex justify-end'>
                  <div className='bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-lg p-2 border border-gray-200/50 dark:border-gray-700/50 w-full lg:w-auto overflow-x-auto'>
                    <div className='flex gap-1.5 justify-end lg:flex-wrap items-center'>
                      {/* 网页播放 */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // 在新标签页打开视频URL
                          window.open(videoUrl, '_blank');
                        }}
                        className='group relative flex items-center justify-center gap-1 w-8 h-8 lg:w-auto lg:h-auto lg:px-2 lg:py-1.5 bg-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-xs font-medium rounded-md transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer overflow-hidden border border-gray-300 dark:border-gray-600 flex-shrink-0'
                        title='网页播放'
                      >
                        <svg
                          className='w-4 h-4 flex-shrink-0 text-gray-700 dark:text-gray-200'
                          fill='none'
                          stroke='currentColor'
                          viewBox='0 0 24 24'
                          xmlns='http://www.w3.org/2000/svg'
                        >
                          <path
                            strokeLinecap='round'
                            strokeLinejoin='round'
                            strokeWidth={2}
                            d='M21 12a9 9 0 11-18 0 9 9 0 0118 0z'
                          />
                          <path
                            strokeLinecap='round'
                            strokeLinejoin='round'
                            strokeWidth={2}
                            d='M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z'
                          />
                        </svg>
                        <span className='hidden lg:inline max-w-0 group-hover:max-w-[100px] overflow-hidden whitespace-nowrap transition-all duration-200 ease-in-out text-gray-700 dark:text-gray-200'>
                          网页播放
                        </span>
                      </button>

                      {/* PotPlayer */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // 直接使用原始 URL,不使用代理
                          window.open(`potplayer://${videoUrl}`, '_blank');
                        }}
                        className='group relative flex items-center justify-center gap-1 w-8 h-8 lg:w-auto lg:h-auto lg:px-2 lg:py-1.5 bg-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-xs font-medium rounded-md transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer overflow-hidden border border-gray-300 dark:border-gray-600 flex-shrink-0'
                        title='PotPlayer'
                      >
                        <img
                          src='/players/potplayer.png'
                          alt='PotPlayer'
                          className='w-4 h-4 flex-shrink-0'
                        />
                        <span className='hidden lg:inline max-w-0 group-hover:max-w-[100px] overflow-hidden whitespace-nowrap transition-all duration-200 ease-in-out text-gray-700 dark:text-gray-200'>
                          PotPlayer
                        </span>
                      </button>

                      {/* VLC */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // 直接使用原始 URL,不使用代理
                          window.open(`vlc://${videoUrl}`, '_blank');
                        }}
                        className='group relative flex items-center justify-center gap-1 w-8 h-8 lg:w-auto lg:h-auto lg:px-2 lg:py-1.5 bg-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-xs font-medium rounded-md transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer overflow-hidden border border-gray-300 dark:border-gray-600 flex-shrink-0'
                        title='VLC'
                      >
                        <img
                          src='/players/vlc.png'
                          alt='VLC'
                          className='w-4 h-4 flex-shrink-0'
                        />
                        <span className='hidden lg:inline max-w-0 group-hover:max-w-[100px] overflow-hidden whitespace-nowrap transition-all duration-200 ease-in-out text-gray-700 dark:text-gray-200'>
                          VLC
                        </span>
                      </button>

                      {/* MPV */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // 直接使用原始 URL,不使用代理
                          window.open(`mpv://${videoUrl}`, '_blank');
                        }}
                        className='group relative flex items-center justify-center gap-1 w-8 h-8 lg:w-auto lg:h-auto lg:px-2 lg:py-1.5 bg-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-xs font-medium rounded-md transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer overflow-hidden border border-gray-300 dark:border-gray-600 flex-shrink-0'
                        title='MPV'
                      >
                        <img
                          src='/players/mpv.png'
                          alt='MPV'
                          className='w-4 h-4 flex-shrink-0'
                        />
                        <span className='hidden lg:inline max-w-0 group-hover:max-w-[100px] overflow-hidden whitespace-nowrap transition-all duration-200 ease-in-out text-gray-700 dark:text-gray-200'>
                          MPV
                        </span>
                      </button>

                      {/* MX Player */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // 直接使用原始 URL,不使用代理
                          window.open(
                            `intent://${videoUrl}#Intent;package=com.mxtech.videoplayer.ad;S.title=${encodeURIComponent(
                              currentChannel?.name || '直播'
                            )};end`,
                            '_blank'
                          );
                        }}
                        className='group relative flex items-center justify-center gap-1 w-8 h-8 lg:w-auto lg:h-auto lg:px-2 lg:py-1.5 bg-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-xs font-medium rounded-md transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer overflow-hidden border border-gray-300 dark:border-gray-600 flex-shrink-0'
                        title='MX Player'
                      >
                        <img
                          src='/players/mxplayer.png'
                          alt='MX Player'
                          className='w-4 h-4 flex-shrink-0'
                        />
                        <span className='hidden lg:inline max-w-0 group-hover:max-w-[100px] overflow-hidden whitespace-nowrap transition-all duration-200 ease-in-out text-gray-700 dark:text-gray-200'>
                          MX Player
                        </span>
                      </button>

                      {/* nPlayer */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // 直接使用原始 URL,不使用代理
                          window.open(`nplayer-${videoUrl}`, '_blank');
                        }}
                        className='group relative flex items-center justify-center gap-1 w-8 h-8 lg:w-auto lg:h-auto lg:px-2 lg:py-1.5 bg-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-xs font-medium rounded-md transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer overflow-hidden border border-gray-300 dark:border-gray-600 flex-shrink-0'
                        title='nPlayer'
                      >
                        <img
                          src='/players/nplayer.png'
                          alt='nPlayer'
                          className='w-4 h-4 flex-shrink-0'
                        />
                        <span className='hidden lg:inline max-w-0 group-hover:max-w-[100px] overflow-hidden whitespace-nowrap transition-all duration-200 ease-in-out text-gray-700 dark:text-gray-200'>
                          nPlayer
                        </span>
                      </button>

                      {/* IINA */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // 直接使用原始 URL,不使用代理
                          window.open(
                            `iina://weblink?url=${encodeURIComponent(videoUrl)}`,
                            '_blank'
                          );
                        }}
                        className='group relative flex items-center justify-center gap-1 w-8 h-8 lg:w-auto lg:h-auto lg:px-2 lg:py-1.5 bg-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-xs font-medium rounded-md transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer overflow-hidden border border-gray-300 dark:border-gray-600 flex-shrink-0'
                        title='IINA'
                      >
                        <img
                          src='/players/iina.png'
                          alt='IINA'
                          className='w-4 h-4 flex-shrink-0'
                        />
                        <span className='hidden lg:inline max-w-0 group-hover:max-w-[100px] overflow-hidden whitespace-nowrap transition-all duration-200 ease-in-out text-gray-700 dark:text-gray-200'>
                          IINA
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 频道列表 */}
            <div className={`h-[330px] lg:h-full md:overflow-hidden transition-all duration-300 ease-in-out ${isChannelListCollapsed
              ? 'md:col-span-1 lg:hidden lg:opacity-0 lg:scale-95'
              : 'md:col-span-1 lg:opacity-100 lg:scale-100'
              }`}>
              <div className='md:ml-2 px-4 py-0 h-full rounded-xl bg-black/10 dark:bg-white/5 flex flex-col border border-white/0 dark:border-white/30 overflow-hidden'>
                {/* 主要的 Tab 切换 */}
                <div className='flex mb-1 -mx-6 flex-shrink-0'>
                  <div
                    onClick={() => setActiveTab('channels')}
                    className={`flex-1 py-3 px-6 text-center cursor-pointer transition-all duration-200 font-medium
                      ${activeTab === 'channels'
                        ? 'text-green-600 dark:text-green-400'
                        : 'text-gray-700 hover:text-green-600 bg-black/5 dark:bg-white/5 dark:text-gray-300 dark:hover:text-green-400 hover:bg-black/3 dark:hover:bg-white/3'
                      }
                    `.trim()}
                  >
                    频道
                  </div>
                  <div
                    onClick={() => setActiveTab('sources')}
                    className={`flex-1 py-3 px-6 text-center cursor-pointer transition-all duration-200 font-medium
                      ${activeTab === 'sources'
                        ? 'text-green-600 dark:text-green-400'
                        : 'text-gray-700 hover:text-green-600 bg-black/5 dark:bg-white/5 dark:text-gray-300 dark:hover:text-green-400 hover:bg-black/3 dark:hover:bg-white/3'
                      }
                    `.trim()}
                  >
                    直播源
                  </div>
                </div>

                {/* 频道 Tab 内容 */}
                {activeTab === 'channels' && (
                  <>
                    {/* 搜索框 */}
                    <div className='mb-3 -mx-6 px-6 flex-shrink-0'>
                      <div className='relative'>
                        <input
                          type='text'
                          value={searchKeyword}
                          onChange={(e) => handleSearch(e.target.value)}
                          placeholder='搜索频道...'
                          disabled={isSwitchingSource}
                          className={`w-full px-3 py-2 pl-9 text-sm bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all ${
                            isSwitchingSource ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                        />
                        <svg
                          className='absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400'
                          fill='none'
                          stroke='currentColor'
                          viewBox='0 0 24 24'
                        >
                          <path
                            strokeLinecap='round'
                            strokeLinejoin='round'
                            strokeWidth={2}
                            d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'
                          />
                        </svg>
                        {searchKeyword && (
                          <button
                            onClick={() => handleSearch('')}
                            className='absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
                          >
                            <svg
                              className='w-4 h-4'
                              fill='none'
                              stroke='currentColor'
                              viewBox='0 0 24 24'
                            >
                              <path
                                strokeLinecap='round'
                                strokeLinejoin='round'
                                strokeWidth={2}
                                d='M6 18L18 6M6 6l12 12'
                              />
                            </svg>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* 分组标签 */}
                    <div className='flex items-center gap-4 mb-4 border-b border-gray-300 dark:border-gray-700 -mx-6 px-6 flex-shrink-0'>
                      {/* 切换状态提示 */}
                      {isSwitchingSource && (
                        <div className='flex items-center gap-2 text-sm text-amber-600 dark:text-amber-400'>
                          <div className='w-2 h-2 bg-amber-500 rounded-full animate-pulse'></div>
                          切换直播源中...
                        </div>
                      )}

                      <div
                        className='flex-1 overflow-x-auto'
                        ref={groupContainerRef}
                        onMouseEnter={() => {
                          // 鼠标进入分组标签区域时，添加滚轮事件监听
                          const container = groupContainerRef.current;
                          if (container) {
                            const handleWheel = (e: WheelEvent) => {
                              if (container.scrollWidth > container.clientWidth) {
                                e.preventDefault();
                                container.scrollLeft += e.deltaY;
                              }
                            };
                            container.addEventListener('wheel', handleWheel, { passive: false });
                            // 将事件处理器存储在容器上，以便后续移除
                            (container as any)._wheelHandler = handleWheel;
                          }
                        }}
                        onMouseLeave={() => {
                          // 鼠标离开分组标签区域时，移除滚轮事件监听
                          const container = groupContainerRef.current;
                          if (container && (container as any)._wheelHandler) {
                            container.removeEventListener('wheel', (container as any)._wheelHandler);
                            delete (container as any)._wheelHandler;
                          }
                        }}
                      >
                        <div className='flex gap-4 min-w-max'>
                          {groupedChannels && Object.keys(groupedChannels).map((group, index) => (
                            <button
                              key={group}
                              data-group={group}
                              ref={(el) => {
                                groupButtonRefs.current[index] = el;
                              }}
                              onClick={() => handleGroupChange(group)}
                              disabled={isSwitchingSource}
                              className={`w-20 relative py-2 text-sm font-medium transition-colors flex-shrink-0 text-center overflow-hidden
                                 ${isSwitchingSource
                                  ? 'text-gray-400 dark:text-gray-600 cursor-not-allowed opacity-50'
                                  : selectedGroup === group
                                    ? 'text-green-500 dark:text-green-400'
                                    : 'text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400'
                                }
                               `.trim()}
                            >
                              <div className='px-1 overflow-hidden whitespace-nowrap' title={group}>
                                {group}
                              </div>
                              {selectedGroup === group && !isSwitchingSource && (
                                <div className='absolute bottom-0 left-0 right-0 h-0.5 bg-green-500 dark:bg-green-400' />
                              )}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* 频道列表 */}
                    <div ref={channelListRef} className='flex-1 overflow-y-auto space-y-2 pb-4'>
                      {mergedChannelItems?.length > 0 ? (
                        mergedChannelItems.map(item => {
                          if (item.type === 'single') {
                            const channel = item.channel;
                            const isActive = channel.id === currentChannel?.id;
                            const testLabel = getLineTestLabel(channel);
                            const testResult = lineTestResults[getLineTestKey(channel)];
                            const isTesting = isTestingLineGroup(getItemChannels(item));
                            return (
                              <button
                                key={channel.id}
                                data-channel-id={channel.id}
                                onClick={() => handlePlayLines(getItemChannels(item))}
                                disabled={isSwitchingSource}
                                className={`w-full p-3 rounded-lg text-left transition-all duration-200 ${isSwitchingSource
                                  ? 'opacity-50 cursor-not-allowed'
                                  : isActive
                                    ? 'bg-green-100 dark:bg-green-900/30 border border-green-300 dark:border-green-700'
                                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                                  }`}
                              >
                                <div className='flex items-center gap-3'>
                                  <div className='w-10 h-10 bg-gray-300 dark:bg-gray-700 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden'>
                                    {channel.logo ? (
                                      <img
                                        src={getLogoUrl(channel.logo, currentSource?.key || '')}
                                        alt={channel.name}
                                        className='w-full h-full rounded object-contain'
                                        loading="lazy"
                                      />
                                    ) : (
                                      <Tv className='w-5 h-5 text-gray-500' />
                                    )}
                                  </div>
                                  <div className='flex-1 min-w-0'>
                                    <div className='flex items-center gap-2 min-w-0 overflow-hidden'>
                                      <div className='text-sm font-medium text-gray-900 dark:text-gray-100 truncate' title={channel.name}>
                                        {channel.name}
                                      </div>
                                      {testLabel && (
                                        <span
                                          title={testLabel}
                                          className={`flex-shrink-0 whitespace-nowrap rounded px-1.5 py-0.5 text-[10px] leading-none ${
                                            testResult?.status === 'ok'
                                              ? 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300'
                                              : testResult?.status === 'fail'
                                                ? 'bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-300'
                                                : 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300'
                                          }`}
                                        >
                                          {getLineTestBadge(channel)}
                                        </span>
                                      )}
                                    </div>
                                    <div className='text-xs text-gray-500 dark:text-gray-400 mt-1 truncate' title={channel.group}>
                                      {channel.group}
                                    </div>
                                  </div>
                                  <div className='flex items-center gap-1 flex-shrink-0'>
                                    <span
                                      role='button'
                                      aria-disabled={isTesting}
                                      title={isTesting ? '测速中' : '测速'}
                                      onClick={(e) => testLineGroup(e, getItemChannels(item))}
                                      className={iconButtonClassName(isTesting)}
                                    >
                                      {isTesting ? <Loader2 className='w-4 h-4 animate-spin' /> : <Gauge className='w-4 h-4' />}
                                    </span>
                                  </div>
                                </div>
                              </button>
                            );
                          }

                          const isExpanded = expandedMergedChannels.includes(item.key);
                          const activeLineIndex = item.channels.findIndex(channel => channel.id === currentChannel?.id);
                          const hasActiveChild = activeLineIndex !== -1;
                          const bestLine = getBestTestedLine(item.channels);
                          const bestLineIndex = bestLine ? item.channels.findIndex(channel => channel.id === bestLine.id) : -1;
                          const isTestingLines = item.channels.some(channel => lineTestResults[getLineTestKey(channel)]?.status === 'testing');
                          const bestLineLabel = bestLine ? getLineTestLabel(bestLine) : '';
                          const bestLineSpeed = bestLine
                            ? formatLineSpeedCompact(lineTestResults[getLineTestKey(bestLine)]?.speedKBps)
                            : '';

                          return (
                            <div
                              key={item.key}
                              className='space-y-2'
                            >
                              <button
                                type='button'
                                onClick={() => {
                                  handlePlayLines(getItemChannels(item));
                                }}
                                disabled={isSwitchingSource}
                                className={`w-full p-3 rounded-lg text-left transition-all duration-200 ${isSwitchingSource
                                  ? 'opacity-50 cursor-not-allowed'
                                  : hasActiveChild
                                    ? 'bg-green-100 dark:bg-green-900/30 border border-green-300 dark:border-green-700'
                                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                                  }`}
                              >
                                <div className='flex items-center gap-3'>
                                  <div className='w-10 h-10 bg-gray-300 dark:bg-gray-700 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden'>
                                    {item.logo ? (
                                      <img
                                        src={getLogoUrl(item.logo, currentSource?.key || '')}
                                        alt={item.name}
                                        className='w-full h-full rounded object-contain'
                                        loading='lazy'
                                      />
                                    ) : (
                                      <Tv className='w-5 h-5 text-gray-500' />
                                    )}
                                  </div>
                                  <div className='flex-1 min-w-0'>
                                    <div className='flex items-center gap-2 min-w-0 overflow-hidden'>
                                      <div className='text-sm font-medium text-gray-900 dark:text-gray-100 truncate' title={item.name}>
                                        {item.name}
                                      </div>
                                      {isTestingLines ? (
                                        <span className='flex-shrink-0 whitespace-nowrap rounded px-1.5 py-0.5 text-[10px] leading-none bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300'>
                                          测速中
                                        </span>
                                      ) : bestLine ? (
                                        <span
                                          title={`推荐线路${bestLineIndex + 1}${bestLineLabel ? ` ${bestLineLabel}` : ''}`}
                                          className='flex-shrink-0 whitespace-nowrap rounded px-1.5 py-0.5 text-[10px] leading-none bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300'
                                        >
                                          {`推荐${bestLineIndex + 1}${bestLineSpeed ? ` ${bestLineSpeed}` : ''}`}
                                        </span>
                                      ) : hasActiveChild ? (
                                        <span className='flex-shrink-0 whitespace-nowrap rounded px-1.5 py-0.5 text-[10px] leading-none bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'>
                                          {`当前${activeLineIndex + 1}`}
                                        </span>
                                      ) : null}
                                    </div>
                                    <div className='text-xs text-gray-500 dark:text-gray-400 mt-1 truncate' title={item.group}>
                                      {`${item.group} · ${item.channels.length} 条线路`}
                                    </div>
                                  </div>
                                  <div className='flex items-center gap-1 flex-shrink-0'>
                                    <div className='flex flex-col gap-1'>
                                      <span
                                        role='button'
                                        aria-disabled={isTestingLines}
                                        title={isTestingLines ? '测速中' : '测速'}
                                        onClick={(e) => testLineGroup(e, getItemChannels(item))}
                                        className={iconButtonClassName(isTestingLines)}
                                      >
                                        {isTestingLines ? <Loader2 className='w-4 h-4 animate-spin' /> : <Gauge className='w-4 h-4' />}
                                      </span>
                                      <span
                                        role='button'
                                        aria-disabled={isTestingLines}
                                        title='测速并选择推荐线路'
                                        onClick={(e) => testAndPickLineGroup(e, getItemChannels(item), item.key)}
                                        className={iconButtonClassName(isTestingLines)}
                                      >
                                        <Wand2 className='w-4 h-4' />
                                      </span>
                                    </div>
                                    <span
                                      role='button'
                                      title={isExpanded ? '收起' : '展开'}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        toggleMergedChannel(item.key);
                                      }}
                                      className={iconButtonClassName(false, isExpanded)}
                                    >
                                      {isExpanded ? <ChevronUp className='w-4 h-4' /> : <ChevronDown className='w-4 h-4' />}
                                    </span>
                                  </div>
                                </div>
                              </button>

                              {isExpanded && (
                                <div className='pl-4 space-y-2'>
                                  {item.channels.map((channel, index) => {
                                    const isActive = channel.id === currentChannel?.id;
                                    const testLabel = getLineTestLabel(channel);
                                    const testResult = lineTestResults[getLineTestKey(channel)];
                                    const isBestLine = bestLine?.id === channel.id;
                                    return (
                                      <button
                                        key={channel.id}
                                        type='button'
                                        data-channel-id={channel.id}
                                        onClick={() => handleChannelChange(channel)}
                                        disabled={isSwitchingSource}
                                        className={`w-full p-3 rounded-lg text-left text-sm transition-all duration-200 ${
                                          isSwitchingSource
                                            ? 'opacity-50 cursor-not-allowed'
                                            : isActive
                                              ? 'bg-green-100 dark:bg-green-900/30 border border-green-300 dark:border-green-700'
                                              : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                                        }`}
                                      >
                                        <div className='flex items-center gap-3'>
                                          <span className='flex-shrink-0 whitespace-nowrap font-medium text-gray-900 dark:text-gray-100 flex items-center gap-2'>
                                            <GitBranch className='w-4 h-4 text-gray-500 dark:text-gray-400' />
                                            {`线路${index + 1}`}
                                          </span>
                                          <div className='flex flex-1 min-w-0 items-center justify-end gap-2 overflow-hidden text-xs'>
                                            {testLabel && (
                                              <span
                                                title={testLabel}
                                                className={`min-w-0 truncate ${
                                                  testResult?.status === 'ok'
                                                    ? 'text-green-600 dark:text-green-400'
                                                    : testResult?.status === 'fail'
                                                      ? 'text-red-500 dark:text-red-400'
                                                      : 'text-amber-600 dark:text-amber-400'
                                                }`}
                                              >
                                                {testLabel}
                                              </span>
                                            )}
                                            {isBestLine && (
                                              <span className='flex-shrink-0 whitespace-nowrap rounded bg-green-100 px-2 py-0.5 text-green-700 dark:bg-green-900/40 dark:text-green-300'>
                                                推荐
                                              </span>
                                            )}
                                            {isActive && (
                                              <span className='flex-shrink-0 whitespace-nowrap text-green-600 dark:text-green-400'>
                                                当前播放
                                              </span>
                                            )}
                                          </div>
                                        </div>
                                      </button>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })
                      ) : (
                        <div className='flex flex-col items-center justify-center py-12 text-center'>
                          <div className='w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4'>
                            {searchKeyword ? (
                              <svg
                                className='w-8 h-8 text-gray-400 dark:text-gray-600'
                                fill='none'
                                stroke='currentColor'
                                viewBox='0 0 24 24'
                              >
                                <path
                                  strokeLinecap='round'
                                  strokeLinejoin='round'
                                  strokeWidth={2}
                                  d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'
                                />
                              </svg>
                            ) : (
                              <Tv className='w-8 h-8 text-gray-400 dark:text-gray-600' />
                            )}
                          </div>
                          <p className='text-gray-500 dark:text-gray-400 font-medium'>
                            {searchKeyword ? '未找到匹配的频道' : '暂无可用频道'}
                          </p>
                          <p className='text-sm text-gray-400 dark:text-gray-500 mt-1'>
                            {searchKeyword ? '请尝试其他搜索关键词' : '请选择其他直播源或稍后再试'}
                          </p>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* 直播源 Tab 内容 */}
                {activeTab === 'sources' && (
                  <div className='flex flex-col h-full mt-4'>
                    <div className='flex-1 overflow-y-auto space-y-2 pb-20'>
                      {liveSources?.length > 0 ? (
                        liveSources.map((source) => {
                          const isCurrentSource = source.key === currentSource?.key;
                          return (
                            <div
                              key={source.key}
                              onClick={() => !isCurrentSource && handleSourceChange(source)}
                              className={`flex items-start gap-3 px-2 py-3 rounded-lg transition-all select-none duration-200 relative
                                ${isCurrentSource
                                  ? 'bg-green-500/10 dark:bg-green-500/20 border-green-500/30 border'
                                  : 'hover:bg-gray-200/50 dark:hover:bg-white/10 hover:scale-[1.02] cursor-pointer'
                                }`.trim()}
                            >
                              {/* 图标 */}
                              <div className='w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-lg flex items-center justify-center flex-shrink-0'>
                                <Radio className='w-6 h-6 text-gray-500' />
                              </div>

                              {/* 信息 */}
                              <div className='flex-1 min-w-0'>
                                <div className='text-sm font-medium text-gray-900 dark:text-gray-100 truncate'>
                                  {source.name}
                                </div>
                                <div className='text-xs text-gray-500 dark:text-gray-400 mt-1'>
                                  {!source.channelNumber || source.channelNumber === 0 ? '-' : `${source.channelNumber} 个频道`}
                                </div>
                              </div>

                              {/* 当前标识 */}
                              {isCurrentSource && (
                                <div className='absolute top-2 right-2 w-2 h-2 bg-green-500 rounded-full'></div>
                              )}
                            </div>
                          );
                        })
                      ) : (
                        <div className='flex flex-col items-center justify-center py-12 text-center'>
                          <div className='w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4'>
                            <Radio className='w-8 h-8 text-gray-400 dark:text-gray-600' />
                          </div>
                          <p className='text-gray-500 dark:text-gray-400 font-medium'>
                            暂无可用直播源
                          </p>
                          <p className='text-sm text-gray-400 dark:text-gray-500 mt-1'>
                            请检查网络连接或联系管理员添加直播源
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 当前频道信息 */}
        {currentChannel && (
          <div className='pt-4'>
            <div className='flex flex-col lg:flex-row gap-4'>
              {/* 频道图标+名称 - 在小屏幕上占100%，大屏幕占20% */}
              <div className='w-full flex-shrink-0'>
                <div className='flex items-center gap-4'>
                  <div className='w-20 h-20 bg-gray-300 dark:bg-gray-700 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden'>
                    {currentChannel.logo ? (
                      <img
                        src={getLogoUrl(currentChannel.logo, currentSource?.key || '')}
                        alt={currentChannel.name}
                        className='w-full h-full rounded object-contain'
                        loading="lazy"
                      />
                    ) : (
                      <Tv className='w-10 h-10 text-gray-500' />
                    )}
                  </div>
                  <div className='flex-1 min-w-0'>
                    <div className='flex items-center gap-3'>
                      <h3 className='text-lg font-semibold text-gray-900 dark:text-gray-100 truncate'>
                        {currentChannel.name}
                      </h3>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleFavorite();
                        }}
                        className='flex-shrink-0 hover:opacity-80 transition-opacity'
                        title={favorited ? '取消收藏' : '收藏'}
                      >
                        <FavoriteIcon filled={favorited} />
                      </button>
                    </div>
                    <p className='text-sm text-gray-500 dark:text-gray-400 truncate'>
                      {currentSource?.name} {' > '} {currentChannel.group}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* EPG节目单 */}
            <EpgScrollableRow
              programs={epgData?.programs || []}
              currentTime={new Date()}
              isLoading={isEpgLoading}
            />
          </div>
        )}
      </div>
    </PageLayout>
  );
}

// FavoriteIcon 组件
const FavoriteIcon = ({ filled }: { filled: boolean }) => {
  if (filled) {
    return (
      <svg
        className='h-6 w-6'
        viewBox='0 0 24 24'
        xmlns='http://www.w3.org/2000/svg'
      >
        <path
          d='M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z'
          fill='#ef4444' /* Tailwind red-500 */
          stroke='#ef4444'
          strokeWidth='2'
          strokeLinecap='round'
          strokeLinejoin='round'
        />
      </svg>
    );
  }
  return (
    <Heart className='h-6 w-6 stroke-[1] text-gray-600 dark:text-gray-300' />
  );
};

export default function LivePage() {
  return <LivePageClient />;
}
